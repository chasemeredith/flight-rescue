#!/usr/bin/env python3
"""Small pre-release check for Flight Rescue's responsive themes and copy."""
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text()
css = (ROOT / "styles.css").read_text()
errors: list[str] = []


def luminance(hex_color: str) -> float:
    values = [int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    linear = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in values]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def contrast(foreground: str, background: str) -> float:
    light, dark = sorted((luminance(foreground), luminance(background)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


required_css = [
    "@media (prefers-reduced-motion:reduce)",
    "@media(max-width:780px)",
]
for marker in required_css:
    if marker not in css:
        errors.append(f"Missing CSS release marker: {marker}")

if css.count("{") != css.count("}"):
    errors.append("CSS braces are unbalanced")

for legacy in ("KEEP, WATCH, or ACT", ">KEEP<", ">WATCH<", ">ACT<", "AI powered"):
    if legacy in html:
        errors.append(f"Outdated copy remains: {legacy}")

for required_copy in ("Turbulence:</b>", "Weather:</b>", "Verified at", "Forecast unavailable"):
    if required_copy not in html:
        errors.append(f"Sample response is missing: {required_copy}")

for foreground, background in (("#13231f", "#e2ded2"),):
    ratio = contrast(foreground, background)
    if ratio < 4.5:
        errors.append(f"Theme contrast {foreground}/{background} is only {ratio:.2f}:1")

if not re.search(r'<meta name="robots" content="noindex,nofollow,noarchive">', html):
    errors.append("Private preview robots protection is missing")

if errors:
    print("Site check failed:")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("Site check passed: original theme, reduced motion, mobile comparison, copy, privacy, and contrast.")
