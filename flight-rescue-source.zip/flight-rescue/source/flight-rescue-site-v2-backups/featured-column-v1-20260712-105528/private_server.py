#!/usr/bin/env python3
import base64, os
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
USER=os.environ.get('SITE_USER','preview'); PASSWORD=os.environ['SITE_PASSWORD']; EXPECTED='Basic '+base64.b64encode(f'{USER}:{PASSWORD}'.encode()).decode()
class Handler(SimpleHTTPRequestHandler):
 def do_GET(self):
  if self.headers.get('Authorization')!=EXPECTED:
   self.send_response(401); self.send_header('WWW-Authenticate','Basic realm="Flight Rescue design v2"'); self.send_header('X-Robots-Tag','noindex, nofollow, noarchive'); self.end_headers(); self.wfile.write(b'Private preview'); return
  super().do_GET()
 def end_headers(self):
  self.send_header('X-Robots-Tag','noindex, nofollow, noarchive'); self.send_header('Cache-Control','no-store'); super().end_headers()
if __name__=='__main__': os.chdir(os.path.dirname(os.path.abspath(__file__))); ThreadingHTTPServer(('127.0.0.1',4175),Handler).serve_forever()
