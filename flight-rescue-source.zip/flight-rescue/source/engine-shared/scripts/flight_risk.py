#!/usr/bin/env python3
"""Deterministic flight-disruption scoring with versioned, unique-flight calibration.

V2 deliberately produces qualitative risk only. Passenger-facing probabilities remain
disabled until a specific model version and forecast-horizon cohort has enough unique,
resolved physical flights.
"""
from __future__ import annotations

import argparse
import json
import math
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

DEFAULT_DB = Path.home() / ".hermes" / "data" / "flight-risk.sqlite"
SCHEMA_VERSION = 4
CURRENT_MODEL_VERSION = "flight-risk-v2"
LEGACY_MODEL_VERSION = "flight-risk-v1-legacy"
LABELS = ((20, "low"), (40, "moderate"), (60, "high"), (101, "severe"))
HORIZONS = ("under_30m", "30m_to_1h", "1h_to_3h", "3h_to_12h", "12h_plus", "unknown", "post_departure")
FORECAST_HORIZONS = frozenset(HORIZONS) - {"post_departure"}
FINAL_STATUSES = ("arrived", "cancelled", "diverted", "returned_to_origin", "unknown")
FACTOR_LABELS = {
    "passenger_flight_delay": "the delay already posted for your flight",
    "upstream_rotation_delay": "delay in the aircraft's upstream rotation",
    "upstream_legs": "the aircraft's remaining upstream flights",
    "minimum_turn": "a tight upstream turnaround",
    "airport_conditions": "airport congestion",
    "weather": "weather affecting the operating window",
    "historical_reliability": "this flight's recent operating history",
    "tail_unconfirmed": "an unconfirmed aircraft assignment",
    "tail_unassigned": "no assigned aircraft",
    "location_uncertainty": "uncertain aircraft location",
}


def classify_airport_conditions(
    *,
    average_delay_minutes: float = 0,
    trend: str = "steady",
    ground_stop: bool = False,
    ground_delay_program: bool = False,
    overlaps_operating_window: bool = True,
    event_id: str | None = None,
) -> dict[str, Any]:
    """Map observable airport constraints to the scorer's 0..3 severity scale."""
    delay = _finite("average_delay_minutes", average_delay_minutes, minimum=0)
    if trend not in {"decreasing", "steady", "increasing"}:
        raise ValueError("trend must be decreasing, steady, or increasing")
    if not overlaps_operating_window:
        severity = 0
    elif ground_stop or delay >= 90:
        severity = 3
    elif ground_delay_program or delay >= 45:
        severity = 2
    elif delay >= 15:
        severity = 1
    else:
        severity = 0
    if trend == "increasing" and severity in {1, 2}:
        severity += 1
    elif trend == "decreasing" and severity in {1, 2}:
        severity -= 1
    return {
        "severity": severity,
        "event_ids": [event_id] if event_id and overlaps_operating_window else [],
        "evidence": {
            "average_delay_minutes": delay,
            "trend": trend,
            "ground_stop": bool(ground_stop),
            "ground_delay_program": bool(ground_delay_program),
            "overlaps_operating_window": bool(overlaps_operating_window),
        },
    }


def classify_weather_conditions(
    *,
    thunderstorm: bool = False,
    visibility_sm: float | None = None,
    ceiling_ft: float | None = None,
    gust_kt: float | None = None,
    freezing_precipitation: bool = False,
    overlaps_operating_window: bool = True,
    event_id: str | None = None,
) -> dict[str, Any]:
    """Map time-matched weather to the scorer's 0..3 severity scale."""
    visibility = None if visibility_sm is None else _finite("visibility_sm", visibility_sm, minimum=0)
    ceiling = None if ceiling_ft is None else _finite("ceiling_ft", ceiling_ft, minimum=0)
    gust = None if gust_kt is None else _finite("gust_kt", gust_kt, minimum=0)
    if not overlaps_operating_window:
        severity = 0
    elif freezing_precipitation or (visibility is not None and visibility < 1) or (ceiling is not None and ceiling < 500):
        severity = 3
    elif thunderstorm or (gust is not None and gust >= 35) or (visibility is not None and visibility < 3) or (ceiling is not None and ceiling < 1000):
        severity = 2
    elif (gust is not None and gust >= 25) or (visibility is not None and visibility < 5) or (ceiling is not None and ceiling < 2000):
        severity = 1
    else:
        severity = 0
    return {
        "severity": severity,
        "event_ids": [event_id] if event_id and overlaps_operating_window else [],
        "evidence": {
            "thunderstorm": bool(thunderstorm),
            "visibility_sm": visibility,
            "ceiling_ft": ceiling,
            "gust_kt": gust,
            "freezing_precipitation": bool(freezing_precipitation),
            "overlaps_operating_window": bool(overlaps_operating_window),
        },
    }


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def risk_label(score: int) -> str:
    return next(label for ceiling, label in LABELS if score < ceiling)


def _finite(name: str, value: Any, *, minimum: float | None = None, maximum: float | None = None) -> float:
    try:
        number = float(value)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{name} must be numeric") from exc
    if not math.isfinite(number):
        raise ValueError(f"{name} must be finite")
    if minimum is not None and number < minimum:
        raise ValueError(f"{name} must be >= {minimum:g}")
    if maximum is not None and number > maximum:
        raise ValueError(f"{name} must be <= {maximum:g}")
    return number


def _integer(name: str, value: Any, *, minimum: int = 0) -> int:
    number = _finite(name, value, minimum=minimum)
    if not number.is_integer():
        raise ValueError(f"{name} must be an integer")
    return int(number)


def _parse_time(value: str) -> datetime:
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise ValueError("timestamps must include a timezone")
    return parsed.astimezone(timezone.utc)


def _utc_text(value: str) -> str:
    return _parse_time(value).isoformat(timespec="seconds")


def horizon_bucket(minutes_to_departure: float | None) -> str:
    if minutes_to_departure is None:
        return "unknown"
    value = _finite("minutes_to_departure", minutes_to_departure)
    if value < 0:
        return "post_departure"
    if value < 30:
        return "under_30m"
    if value < 60:
        return "30m_to_1h"
    if value < 180:
        return "1h_to_3h"
    if value < 720:
        return "3h_to_12h"
    return "12h_plus"


def validate_inputs(data: dict[str, Any]) -> tuple[dict[str, Any], list[str]]:
    required = (
        "passenger_flight_delay_minutes",
        "upstream_rotation_delay_minutes",
        "upstream_legs",
        "tail_status",
        "location_confidence",
        "airport_severity",
        "weather_severity",
    )
    missing = [name for name in required if data.get(name) is None]
    if missing:
        return {}, missing

    clean: dict[str, Any] = {
        "passenger_flight_delay_minutes": _finite("passenger_flight_delay_minutes", data["passenger_flight_delay_minutes"], minimum=0),
        "upstream_rotation_delay_minutes": _finite("upstream_rotation_delay_minutes", data["upstream_rotation_delay_minutes"], minimum=0),
        "upstream_legs": _integer("upstream_legs", data["upstream_legs"]),
        "airport_severity": _integer("airport_severity", data["airport_severity"]),
        "weather_severity": _integer("weather_severity", data["weather_severity"]),
    }
    if clean["airport_severity"] > 3 or clean["weather_severity"] > 3:
        raise ValueError("airport_severity and weather_severity must be between 0 and 3")

    clean["tail_status"] = str(data["tail_status"])
    if clean["tail_status"] not in {"confirmed", "unconfirmed", "unassigned"}:
        raise ValueError("tail_status must be confirmed, unconfirmed, or unassigned")
    clean["location_confidence"] = str(data["location_confidence"])
    if clean["location_confidence"] not in {"live", "actual", "completed_leg", "scheduled", "unknown"}:
        raise ValueError("invalid location_confidence")

    turn = data.get("minimum_turn_minutes")
    clean["minimum_turn_minutes"] = None if turn is None else _finite("minimum_turn_minutes", turn, minimum=0)
    recovery = data.get("recovery_buffer_minutes")
    clean["recovery_buffer_minutes"] = None if recovery is None else _finite("recovery_buffer_minutes", recovery, minimum=0)

    hist_rate = data.get("historical_on_time_rate")
    clean["historical_on_time_rate"] = None if hist_rate is None else _finite("historical_on_time_rate", hist_rate, minimum=0, maximum=1)
    clean["historical_sample"] = _integer("historical_sample", data.get("historical_sample", 0) or 0)
    for key in ("airport_event_ids", "weather_event_ids"):
        values = data.get(key, []) or []
        if not isinstance(values, (list, tuple, set)) or not all(isinstance(value, str) and value for value in values):
            raise ValueError(f"{key} must contain non-empty strings")
        clean[key] = sorted(set(values))
    return clean, []


def score_flight(data: dict[str, Any]) -> dict[str, Any]:
    clean, missing = validate_inputs(data)
    if missing:
        return {
            "assessment_complete": False,
            "missing_inputs": missing,
            "risk_score": None,
            "risk_label": "unknown",
            "weak_points": [],
            "mitigations": [],
            "factors": [],
            "passenger_wording": "I do not have enough confirmed information to assess this flight yet.",
            "probability_publishable": False,
            "model_version": CURRENT_MODEL_VERSION,
        }

    factors: list[dict[str, Any]] = []

    def add(name: str, gross: float, evidence: Any, *, propagation: bool = False) -> None:
        if gross:
            factors.append({
                "factor": name,
                "gross_points": round(gross, 1),
                "mitigation_points": 0.0,
                "residual_points": round(gross, 1),
                "evidence": evidence,
                "propagation": propagation,
            })

    passenger_delay = clean["passenger_flight_delay_minutes"]
    add("passenger_flight_delay", min(30.0, passenger_delay / 3.0), f"{passenger_delay:g} minutes")

    upstream_delay = clean["upstream_rotation_delay_minutes"]
    add("upstream_rotation_delay", min(30.0, upstream_delay / 3.0), f"{upstream_delay:g} minutes", propagation=True)

    legs = clean["upstream_legs"]
    add("upstream_legs", min(12.0, legs * 3.0), legs, propagation=True)

    turn = clean["minimum_turn_minutes"]
    if turn is not None:
        turn_points = 20 if turn < 30 else 12 if turn < 45 else 5 if turn < 60 else 0
        add("minimum_turn", turn_points, f"{turn:g} minutes", propagation=True)

    mitigations: list[str] = []
    recovery = clean["recovery_buffer_minutes"]
    propagation = [factor for factor in factors if factor["propagation"]]
    propagation_total = sum(float(factor["gross_points"]) for factor in propagation)
    if recovery is not None and propagation_total > 0:
        # Recovery scales against the propagation exposure itself. Three hours
        # of genuine slack fully retires an earlier turn/delay as a current
        # weak point, while the passenger flight's own delay remains untouched.
        recovery_fraction = clamp((recovery - 30.0) / 180.0, 0.0, 1.0)
        credit = propagation_total * recovery_fraction
        ratio = credit / propagation_total
        for factor in propagation:
            mitigation = float(factor["gross_points"]) * ratio
            factor["mitigation_points"] = round(mitigation, 1)
            factor["residual_points"] = round(float(factor["gross_points"]) - mitigation, 1)
        if credit > 0:
            mitigations.append(f"{recovery:g} minutes of recovery time before the passenger flight")

    airport = clean["airport_severity"]
    add("airport_conditions", airport * 8, airport)
    weather = clean["weather_severity"]
    add("weather", weather * 8, weather)
    shared_events = sorted(set(clean["airport_event_ids"]) & set(clean["weather_event_ids"]))
    if shared_events and airport and weather:
        airport_factor = next(f for f in factors if f["factor"] == "airport_conditions")
        weather_factor = next(f for f in factors if f["factor"] == "weather")
        correlation_credit = min(8.0, float(airport_factor["residual_points"]), float(weather_factor["residual_points"]))
        weather_factor["mitigation_points"] = round(float(weather_factor["mitigation_points"]) + correlation_credit, 1)
        weather_factor["residual_points"] = round(float(weather_factor["residual_points"]) - correlation_credit, 1)
        mitigations.append("correlated airport and weather evidence was counted only once")

    hist_rate = clean["historical_on_time_rate"]
    hist_n = clean["historical_sample"]
    if hist_rate is not None and hist_n >= 20:
        hist_points = 12 if hist_rate < 0.60 else 6 if hist_rate < 0.75 else 0
        add("historical_reliability", hist_points, {"on_time_rate": hist_rate, "sample": hist_n})

    tail_status = clean["tail_status"]
    if tail_status == "unconfirmed":
        add("tail_unconfirmed", 10, tail_status)
    elif tail_status == "unassigned":
        add("tail_unassigned", 12, tail_status)

    location = clean["location_confidence"]
    location_points = {"live": 0, "actual": 0, "completed_leg": 2, "scheduled": 8, "unknown": 12}[location]
    add("location_uncertainty", location_points, location)

    score = int(round(clamp(sum(float(f["residual_points"]) for f in factors), 0, 100)))
    label = risk_label(score)
    ranked = sorted((f for f in factors if float(f["residual_points"]) > 0), key=lambda x: float(x["residual_points"]), reverse=True)
    weak_points = [FACTOR_LABELS.get(f["factor"], f["factor"]) for f in ranked[:3]]
    wording = f"{label.capitalize()} disruption risk"
    if weak_points:
        wording += f"; main concern: {weak_points[0]}"
    if mitigations:
        wording += f"; mitigation: {mitigations[0]}"

    for factor in factors:
        factor.pop("propagation", None)
    return {
        "assessment_complete": True,
        "missing_inputs": [],
        "risk_score": score,
        "risk_label": label,
        "weak_points": weak_points,
        "mitigations": mitigations,
        "factors": factors,
        "passenger_wording": wording,
        "probability_publishable": False,
        "model_version": CURRENT_MODEL_VERSION,
    }


def _columns(conn: sqlite3.Connection, table: str) -> set[str]:
    return {str(row[1]) for row in conn.execute(f"PRAGMA table_info({table})")}


def connect(db_path: Path) -> sqlite3.Connection:
    db_path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(
        """
        CREATE TABLE IF NOT EXISTS schema_metadata (key TEXT PRIMARY KEY, value TEXT NOT NULL);
        CREATE TABLE IF NOT EXISTS predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flight_id TEXT NOT NULL,
            assessed_at TEXT NOT NULL,
            risk_score INTEGER,
            risk_label TEXT NOT NULL,
            raw_probability REAL,
            inputs_json TEXT NOT NULL,
            factors_json TEXT NOT NULL,
            resolved_at TEXT,
            outcome_delay_minutes REAL,
            on_time INTEGER
        );
        CREATE TABLE IF NOT EXISTS flight_outcomes (
            flight_id TEXT PRIMARY KEY,
            resolved_at TEXT NOT NULL,
            final_status TEXT NOT NULL,
            departure_delay_minutes REAL,
            arrival_delay_minutes REAL,
            diverted INTEGER NOT NULL DEFAULT 0,
            cancelled INTEGER NOT NULL DEFAULT 0,
            returned_to_origin INTEGER NOT NULL DEFAULT 0,
            operated_as_planned INTEGER NOT NULL,
            arrived_within_15 INTEGER,
            major_disruption INTEGER NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS outcome_audit (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flight_id TEXT NOT NULL,
            changed_at TEXT NOT NULL,
            previous_json TEXT,
            replacement_json TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS rescue_outcomes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            flight_id TEXT NOT NULL,
            recorded_at TEXT NOT NULL,
            recommendation TEXT NOT NULL,
            traveler_action TEXT NOT NULL,
            replacement_flight_id TEXT,
            original_expected_arrival TEXT,
            actual_traveler_arrival TEXT,
            minutes_saved REAL,
            incremental_cost REAL,
            currency TEXT,
            notes TEXT,
            idempotency_key TEXT
        );
        CREATE TABLE IF NOT EXISTS flight_instances (
            flight_id TEXT PRIMARY KEY,
            provider TEXT NOT NULL,
            marketing_ident TEXT,
            operating_ident TEXT,
            origin TEXT,
            destination TEXT,
            service_date TEXT,
            scheduled_departure TEXT,
            created_at TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_predictions_flight ON predictions(flight_id);
        CREATE INDEX IF NOT EXISTS idx_predictions_resolved ON predictions(on_time);
        """
    )
    columns = _columns(conn, "predictions")
    migrations = {
        "model_version": f"TEXT NOT NULL DEFAULT '{LEGACY_MODEL_VERSION}'",
        "scheduled_departure": "TEXT",
        "minutes_to_departure": "REAL",
        "horizon_bucket": "TEXT NOT NULL DEFAULT 'unknown'",
        "assessment_complete": "INTEGER NOT NULL DEFAULT 1",
        "marketing_ident": "TEXT",
        "operating_ident": "TEXT",
        "origin": "TEXT",
        "destination": "TEXT",
        "service_date": "TEXT",
    }
    for name, definition in migrations.items():
        if name not in columns:
            conn.execute(f"ALTER TABLE predictions ADD COLUMN {name} {definition}")
    rescue_columns = _columns(conn, "rescue_outcomes")
    if "idempotency_key" not in rescue_columns:
        conn.execute("ALTER TABLE rescue_outcomes ADD COLUMN idempotency_key TEXT")
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_rescue_idempotency ON rescue_outcomes(idempotency_key) WHERE idempotency_key IS NOT NULL")
    # Register legacy/current rows so outcome and rescue writes can validate identity.
    conn.execute(
        """INSERT OR IGNORE INTO flight_instances
        (flight_id,provider,marketing_ident,operating_ident,origin,destination,service_date,scheduled_departure,created_at)
        SELECT flight_id,'flightaware',MAX(marketing_ident),MAX(operating_ident),MAX(origin),MAX(destination),MAX(service_date),MAX(scheduled_departure),MIN(assessed_at)
        FROM predictions GROUP BY flight_id"""
    )
    conn.execute(
        "INSERT INTO schema_metadata(key,value) VALUES('schema_version',?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (str(SCHEMA_VERSION),),
    )
    conn.commit()
    return conn


def record_prediction(
    conn: sqlite3.Connection,
    flight_id: str,
    assessed_at: str,
    inputs: dict[str, Any],
    result: dict[str, Any],
    *,
    scheduled_departure: str | None = None,
    marketing_ident: str | None = None,
    operating_ident: str | None = None,
    origin: str | None = None,
    destination: str | None = None,
    service_date: str | None = None,
    provider: str = "flightaware",
) -> int:
    if not result.get("assessment_complete"):
        raise ValueError("incomplete assessments cannot be recorded")
    flight_id = flight_id.strip()
    provider = provider.strip().lower()
    if not flight_id:
        raise ValueError("flight_id must be a non-empty physical-flight identifier")
    if not provider:
        raise ValueError("provider must be non-empty")
    assessed = _parse_time(assessed_at)
    assessed_at = assessed.isoformat(timespec="seconds")
    normalized_departure = _utc_text(scheduled_departure) if scheduled_departure else None
    minutes = None
    if normalized_departure:
        minutes = (_parse_time(normalized_departure) - assessed).total_seconds() / 60
    horizon = horizon_bucket(minutes)

    identity = {
        "provider": provider,
        "marketing_ident": marketing_ident,
        "operating_ident": operating_ident,
        "origin": origin,
        "destination": destination,
        "service_date": service_date,
        "scheduled_departure": normalized_departure,
    }
    existing = conn.execute("SELECT * FROM flight_instances WHERE flight_id=?", (flight_id,)).fetchone()
    if existing:
        conflicts = [key for key, value in identity.items() if value is not None and existing[key] is not None and str(existing[key]) != str(value)]
        if conflicts:
            raise ValueError(f"physical-flight metadata conflict for {flight_id}: {', '.join(conflicts)}")
        updates = {key: value for key, value in identity.items() if value is not None and existing[key] is None}
        if updates:
            conn.execute("UPDATE flight_instances SET " + ",".join(f"{key}=?" for key in updates) + " WHERE flight_id=?", (*updates.values(), flight_id))
    else:
        conn.execute(
            "INSERT INTO flight_instances(flight_id,provider,marketing_ident,operating_ident,origin,destination,service_date,scheduled_departure,created_at) VALUES(?,?,?,?,?,?,?,?,?)",
            (flight_id, provider, marketing_ident, operating_ident, origin, destination, service_date, normalized_departure, utc_now()),
        )

    cur = conn.execute(
        """INSERT INTO predictions
        (flight_id, assessed_at, scheduled_departure, minutes_to_departure, horizon_bucket,
         model_version, assessment_complete, risk_score, risk_label, raw_probability,
         inputs_json, factors_json, marketing_ident, operating_ident, origin, destination, service_date)
        VALUES (?, ?, ?, ?, ?, ?, 1, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
        (
            flight_id, assessed_at, normalized_departure, minutes, horizon,
            result["model_version"], result["risk_score"], result["risk_label"], None,
            json.dumps(inputs, sort_keys=True), json.dumps(result["factors"], sort_keys=True),
            marketing_ident, operating_ident, origin, destination, service_date,
        ),
    )
    conn.commit()
    return int(cur.lastrowid)


def _outcome_payload(final_status: str, departure_delay: float | None, arrival_delay: float | None, resolved_at: str) -> dict[str, Any]:
    if final_status not in FINAL_STATUSES:
        raise ValueError(f"final_status must be one of {', '.join(FINAL_STATUSES)}")
    departure = None if departure_delay is None else _finite("departure_delay_minutes", departure_delay)
    arrival = None if arrival_delay is None else _finite("arrival_delay_minutes", arrival_delay)
    if final_status == "arrived" and arrival is None:
        raise ValueError("arrival_delay_minutes is required for arrived flights")
    cancelled = final_status == "cancelled"
    diverted = final_status == "diverted"
    returned = final_status == "returned_to_origin"
    arrived_within = int(arrival <= 15) if final_status == "arrived" and arrival is not None else None
    major = int(cancelled or diverted or returned or (arrival is not None and arrival >= 60))
    operated = int(final_status == "arrived" and arrived_within == 1)
    return {
        "resolved_at": _utc_text(resolved_at),
        "final_status": final_status,
        "departure_delay_minutes": departure,
        "arrival_delay_minutes": arrival,
        "diverted": int(diverted),
        "cancelled": int(cancelled),
        "returned_to_origin": int(returned),
        "operated_as_planned": operated,
        "arrived_within_15": arrived_within,
        "major_disruption": major,
        "updated_at": utc_now(),
    }


def resolve_flight(
    conn: sqlite3.Connection,
    flight_id: str,
    *,
    final_status: str,
    resolved_at: str,
    departure_delay_minutes: float | None = None,
    arrival_delay_minutes: float | None = None,
    correct: bool = False,
) -> dict[str, Any]:
    prediction_count = int(conn.execute("SELECT COUNT(*) FROM predictions WHERE flight_id=?", (flight_id,)).fetchone()[0])
    if prediction_count == 0:
        return {"status": "unknown_flight", "flight_id": flight_id}
    payload = _outcome_payload(final_status, departure_delay_minutes, arrival_delay_minutes, resolved_at)
    existing = conn.execute("SELECT * FROM flight_outcomes WHERE flight_id=?", (flight_id,)).fetchone()
    if existing:
        substantive_keys = (
            "final_status", "departure_delay_minutes", "arrival_delay_minutes", "diverted",
            "cancelled", "returned_to_origin", "operated_as_planned", "arrived_within_15", "major_disruption",
        )
        comparable = {key: existing[key] for key in substantive_keys}
        incoming = {key: payload[key] for key in substantive_keys}
        if comparable == incoming:
            # A later polling observation of the same final result is idempotent.
            if payload["resolved_at"] > existing["resolved_at"]:
                conn.execute("UPDATE flight_outcomes SET resolved_at=?, updated_at=? WHERE flight_id=?", (payload["resolved_at"], payload["updated_at"], flight_id))
                conn.execute("UPDATE predictions SET resolved_at=? WHERE flight_id=?", (payload["resolved_at"], flight_id))
                conn.commit()
            return {"status": "already_resolved", "flight_id": flight_id}
        if not correct:
            return {"status": "conflicting_outcome", "flight_id": flight_id}
        conn.execute(
            "INSERT INTO outcome_audit(flight_id,changed_at,previous_json,replacement_json) VALUES(?,?,?,?)",
            (flight_id, utc_now(), json.dumps(dict(existing), sort_keys=True), json.dumps(payload, sort_keys=True)),
        )
    columns = ",".join(payload)
    placeholders = ",".join("?" for _ in payload)
    updates = ",".join(f"{name}=excluded.{name}" for name in payload)
    conn.execute(
        f"INSERT INTO flight_outcomes(flight_id,{columns}) VALUES(?,{placeholders}) "
        f"ON CONFLICT(flight_id) DO UPDATE SET {updates}",
        (flight_id, *payload.values()),
    )
    legacy_on_time = payload["arrived_within_15"]
    conn.execute(
        "UPDATE predictions SET resolved_at=?, outcome_delay_minutes=?, on_time=? WHERE flight_id=?",
        (payload["resolved_at"], payload["arrival_delay_minutes"], legacy_on_time, flight_id),
    )
    conn.commit()
    return {"status": "corrected" if existing else "resolved", "flight_id": flight_id, "prediction_snapshots": prediction_count}


def resolve_predictions(conn: sqlite3.Connection, flight_id: str, delay: float, resolved_at: str) -> int:
    """Backward-compatible resolver for arrived flights."""
    result = resolve_flight(conn, flight_id, final_status="arrived", resolved_at=resolved_at, arrival_delay_minutes=delay)
    return result.get("prediction_snapshots", 0) if result["status"] == "resolved" else 0


def record_rescue_outcome(
    conn: sqlite3.Connection,
    flight_id: str,
    *,
    recommendation: str,
    traveler_action: str,
    recorded_at: str,
    replacement_flight_id: str | None = None,
    original_expected_arrival: str | None = None,
    actual_traveler_arrival: str | None = None,
    minutes_saved: float | None = None,
    incremental_cost: float | None = None,
    currency: str | None = None,
    notes: str | None = None,
    idempotency_key: str | None = None,
) -> int:
    flight_id = flight_id.strip()
    if not recommendation.strip() or not traveler_action.strip():
        raise ValueError("recommendation and traveler_action are required")
    if not flight_id or conn.execute("SELECT 1 FROM flight_instances WHERE flight_id=?", (flight_id,)).fetchone() is None:
        raise ValueError("rescue outcome requires a known physical flight")
    recorded_at = _utc_text(recorded_at)
    original_dt = _parse_time(original_expected_arrival) if original_expected_arrival else None
    actual_dt = _parse_time(actual_traveler_arrival) if actual_traveler_arrival else None
    original_expected_arrival = original_dt.isoformat(timespec="seconds") if original_dt else None
    actual_traveler_arrival = actual_dt.isoformat(timespec="seconds") if actual_dt else None
    saved = None if minutes_saved is None else _finite("minutes_saved", minutes_saved)
    if original_dt and actual_dt:
        derived = (original_dt - actual_dt).total_seconds() / 60
        if saved is None:
            saved = derived
        elif not math.isclose(saved, derived, abs_tol=0.5):
            raise ValueError("minutes_saved does not match the supplied arrival timestamps")
    cost = None if incremental_cost is None else _finite("incremental_cost", incremental_cost, minimum=0)
    if cost is not None and not currency:
        raise ValueError("currency is required when incremental_cost is supplied")
    key = idempotency_key.strip() if idempotency_key else None
    if idempotency_key is not None and not key:
        raise ValueError("idempotency_key must be non-empty")
    if key:
        existing = conn.execute("SELECT id FROM rescue_outcomes WHERE idempotency_key=?", (key,)).fetchone()
        if existing:
            return int(existing["id"])
    cur = conn.execute(
        """INSERT INTO rescue_outcomes
        (flight_id,recorded_at,recommendation,traveler_action,replacement_flight_id,
         original_expected_arrival,actual_traveler_arrival,minutes_saved,incremental_cost,currency,notes,idempotency_key)
        VALUES(?,?,?,?,?,?,?,?,?,?,?,?)""",
        (flight_id, recorded_at, recommendation.strip(), traveler_action.strip(), replacement_flight_id,
         original_expected_arrival, actual_traveler_arrival, saved, cost, currency, notes, key),
    )
    conn.commit()
    return int(cur.lastrowid)


def wilson_interval(successes: int, n: int, z: float = 1.96) -> tuple[float, float]:
    if n == 0:
        return (0.0, 1.0)
    p = successes / n
    denom = 1 + z * z / n
    center = (p + z * z / (2 * n)) / denom
    margin = z * math.sqrt((p * (1 - p) + z * z / (4 * n)) / n) / denom
    return (max(0.0, center - margin), min(1.0, center + margin))


def _canonical_rows(conn: sqlite3.Connection, model_version: str, horizon: str) -> list[sqlite3.Row]:
    return conn.execute(
        """WITH ranked AS (
          SELECT p.*, o.arrived_within_15, o.major_disruption, o.final_status,
                 ROW_NUMBER() OVER (
                   PARTITION BY p.flight_id, p.model_version, p.horizon_bucket
                   ORDER BY datetime(p.assessed_at) DESC, p.id DESC
                 ) AS rn
          FROM predictions p
          JOIN flight_outcomes o ON o.flight_id=p.flight_id
          WHERE p.model_version=? AND p.horizon_bucket=? AND o.final_status != 'unknown'
        )
        SELECT * FROM ranked WHERE rn=1""",
        (model_version, horizon),
    ).fetchall()


def report_calibration(
    conn: sqlite3.Connection,
    min_total: int = 100,
    min_bin: int = 20,
    *,
    model_version: str = CURRENT_MODEL_VERSION,
    horizon: str | None = None,
    validation_passed: bool = False,
) -> dict[str, Any]:
    min_total = _integer("min_total", min_total, minimum=1)
    min_bin = _integer("min_bin", min_bin, minimum=1)
    horizons = [horizon] if horizon else list(HORIZONS)
    for item in horizons:
        if item not in HORIZONS:
            raise ValueError(f"invalid horizon: {item}")
    unique_total = int(conn.execute(
        "SELECT COUNT(DISTINCT p.flight_id) FROM predictions p JOIN flight_outcomes o ON o.flight_id=p.flight_id "
        "WHERE p.model_version=? AND o.final_status != 'unknown' AND p.horizon_bucket != 'post_departure'",
        (model_version,),
    ).fetchone()[0])
    reports: dict[str, Any] = {}
    enabled = False
    for item in horizons:
        rows = _canonical_rows(conn, model_version, item)
        horizon_total = len({str(row["flight_id"]) for row in rows})
        is_forecast = item in FORECAST_HORIZONS
        bins = []
        for low, high in ((0, 19), (20, 39), (40, 59), (60, 100)):
            selected = [row for row in rows if row["risk_score"] is not None and low <= int(row["risk_score"]) <= high]
            n = len({str(row["flight_id"]) for row in selected})
            arrived = [row for row in selected if row["arrived_within_15"] is not None]
            arrived_n = len(arrived)
            on_time_successes = sum(int(row["arrived_within_15"]) for row in arrived)
            major_disruptions = sum(int(row["major_disruption"]) for row in selected)
            on_time_sample_ready = is_forecast and horizon_total >= min_total and arrived_n >= min_bin and arrived_n > 0
            major_sample_ready = is_forecast and horizon_total >= min_total and n >= min_bin and n > 0
            on_time_publishable = on_time_sample_ready and validation_passed
            major_publishable = major_sample_ready and validation_passed
            on_time_low, on_time_high = wilson_interval(on_time_successes, arrived_n)
            major_low, major_high = wilson_interval(major_disruptions, n)
            enabled = enabled or on_time_publishable or major_publishable
            bins.append({
                "risk_score_bin": f"{low}-{high}",
                "unique_flights": n,
                "arrived_outcomes": arrived_n,
                "on_time_sample_ready": on_time_sample_ready,
                "on_time_publishable": on_time_publishable,
                "observed_on_time_rate": round(on_time_successes / arrived_n, 4) if on_time_sample_ready else None,
                "on_time_confidence_interval_95": [round(on_time_low, 4), round(on_time_high, 4)] if on_time_sample_ready else None,
                "major_disruption_sample_ready": major_sample_ready,
                "major_disruption_publishable": major_publishable,
                "observed_major_disruption_rate": round(major_disruptions / n, 4) if major_sample_ready else None,
                "major_disruption_confidence_interval_95": [round(major_low, 4), round(major_high, 4)] if major_sample_ready else None,
            })
        reports[item] = {"canonical_predictions": len(rows), "eligible_unique_flights": horizon_total, "forecast_cohort": is_forecast, "bins": bins}
    snapshot_count = int(conn.execute("SELECT COUNT(*) FROM predictions WHERE model_version=?", (model_version,)).fetchone()[0])
    return {
        "model_version": model_version,
        "prediction_snapshots": snapshot_count,
        "unique_resolved_flights": unique_total,
        "minimum_total_for_probabilities": min_total,
        "minimum_bin_for_probability": min_bin,
        "probabilities_enabled": enabled,
        "publication_blocker": None if enabled else ("out_of_sample_validation_required" if not validation_passed else "sample_thresholds_not_met"),
        "validation_passed": bool(validation_passed),
        "internal_brier_score": None,
        "horizons": reports,
    }


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    sub = parser.add_subparsers(dest="command", required=True)

    assess = sub.add_parser("assess")
    assess.add_argument("--flight-id", required=True, help="Stable physical-flight ID, preferably fa_flight_id")
    assess.add_argument("--flight-provider", default="flightaware")
    assess.add_argument("--assessed-at", default=None)
    assess.add_argument("--scheduled-departure")
    assess.add_argument("--passenger-flight-delay-minutes", type=float, required=True)
    assess.add_argument("--upstream-rotation-delay-minutes", type=float, required=True)
    assess.add_argument("--upstream-legs", type=int, required=True)
    assess.add_argument("--minimum-turn-minutes", type=float)
    assess.add_argument("--recovery-buffer-minutes", type=float)
    assess.add_argument("--airport-severity", type=int, choices=range(4), required=True)
    assess.add_argument("--weather-severity", type=int, choices=range(4), required=True)
    assess.add_argument("--airport-event-id", action="append", default=[])
    assess.add_argument("--weather-event-id", action="append", default=[])
    assess.add_argument("--historical-on-time-rate", type=float)
    assess.add_argument("--historical-sample", type=int, default=0)
    assess.add_argument("--tail-status", choices=["confirmed", "unconfirmed", "unassigned"], required=True)
    assess.add_argument("--location-confidence", choices=["live", "actual", "completed_leg", "scheduled", "unknown"], required=True)
    assess.add_argument("--marketing-ident")
    assess.add_argument("--operating-ident")
    assess.add_argument("--origin")
    assess.add_argument("--destination")
    assess.add_argument("--service-date")
    assess.add_argument("--record", action="store_true")

    resolve = sub.add_parser("resolve")
    resolve.add_argument("--flight-id", required=True)
    resolve.add_argument("--final-status", choices=FINAL_STATUSES, required=True)
    resolve.add_argument("--departure-delay-minutes", type=float)
    resolve.add_argument("--arrival-delay-minutes", type=float)
    resolve.add_argument("--resolved-at", default=None)
    resolve.add_argument("--correct", action="store_true")

    rescue = sub.add_parser("rescue-outcome")
    rescue.add_argument("--flight-id", required=True)
    rescue.add_argument("--recommendation", required=True)
    rescue.add_argument("--traveler-action", required=True)
    rescue.add_argument("--replacement-flight-id")
    rescue.add_argument("--original-expected-arrival")
    rescue.add_argument("--actual-traveler-arrival")
    rescue.add_argument("--minutes-saved", type=float)
    rescue.add_argument("--incremental-cost", type=float)
    rescue.add_argument("--currency")
    rescue.add_argument("--notes")
    rescue.add_argument("--recorded-at", default=None)
    rescue.add_argument("--idempotency-key")

    report = sub.add_parser("report")
    report.add_argument("--min-total", type=int, default=100)
    report.add_argument("--min-bin", type=int, default=20)
    report.add_argument("--model-version", default=CURRENT_MODEL_VERSION)
    report.add_argument("--horizon", choices=HORIZONS)
    report.add_argument("--validation-passed", action="store_true", help="Set only after documented out-of-sample validation")
    return parser


def main() -> None:
    args = build_parser().parse_args()
    conn = connect(args.db)
    try:
        if args.command == "assess":
            inputs = {
                "passenger_flight_delay_minutes": args.passenger_flight_delay_minutes,
                "upstream_rotation_delay_minutes": args.upstream_rotation_delay_minutes,
                "upstream_legs": args.upstream_legs,
                "minimum_turn_minutes": args.minimum_turn_minutes,
                "recovery_buffer_minutes": args.recovery_buffer_minutes,
                "airport_severity": args.airport_severity,
                "weather_severity": args.weather_severity,
                "airport_event_ids": args.airport_event_id,
                "weather_event_ids": args.weather_event_id,
                "historical_on_time_rate": args.historical_on_time_rate,
                "historical_sample": args.historical_sample,
                "tail_status": args.tail_status,
                "location_confidence": args.location_confidence,
            }
            result = score_flight(inputs)
            if args.record:
                result["prediction_id"] = record_prediction(
                    conn, args.flight_id, args.assessed_at or utc_now(), inputs, result,
                    scheduled_departure=args.scheduled_departure,
                    marketing_ident=args.marketing_ident, operating_ident=args.operating_ident,
                    origin=args.origin, destination=args.destination, service_date=args.service_date,
                    provider=args.flight_provider,
                )
            print(json.dumps(result, indent=2, sort_keys=True))
        elif args.command == "resolve":
            result = resolve_flight(
                conn, args.flight_id, final_status=args.final_status,
                departure_delay_minutes=args.departure_delay_minutes,
                arrival_delay_minutes=args.arrival_delay_minutes,
                resolved_at=args.resolved_at or utc_now(), correct=args.correct,
            )
            print(json.dumps(result, indent=2, sort_keys=True))
        elif args.command == "rescue-outcome":
            outcome_id = record_rescue_outcome(
                conn, args.flight_id, recommendation=args.recommendation,
                traveler_action=args.traveler_action, recorded_at=args.recorded_at or utc_now(),
                replacement_flight_id=args.replacement_flight_id,
                original_expected_arrival=args.original_expected_arrival,
                actual_traveler_arrival=args.actual_traveler_arrival,
                minutes_saved=args.minutes_saved, incremental_cost=args.incremental_cost,
                currency=args.currency, notes=args.notes,
                idempotency_key=args.idempotency_key,
            )
            print(json.dumps({"flight_id": args.flight_id, "rescue_outcome_id": outcome_id}, indent=2, sort_keys=True))
        else:
            print(json.dumps(report_calibration(
                conn, args.min_total, args.min_bin,
                model_version=args.model_version, horizon=args.horizon,
                validation_passed=args.validation_passed,
            ), indent=2, sort_keys=True))
    except ValueError as exc:
        raise SystemExit(f"error: {exc}") from exc
    finally:
        conn.close()


if __name__ == "__main__":
    main()
