# Interpreting a Flight-Disruption Shadow Beta

Use this when reporting or adapting an observational flight-risk experiment.

## Preserve the baseline

- Do not change an unbiased cohort midstream merely because disruptions are rare.
- Finish the approved baseline first. If it yields too few meaningful disruptions, run a separately labeled disruption-enriched challenge cohort afterward.
- Never mix challenge-cohort results into baseline prevalence, accuracy, false-alarm, or calibration figures.

## Separate three questions

Report these independently:

1. **Risk detection:** Did the predeparture snapshot identify the disrupted original flight?
2. **Decision quality:** Given information available at decision time, was `stay` or `switch` correct?
3. **Replacement quality:** When `switch` was recommended, did the frozen alternative actually arrive earlier after operational risk and fare constraints?

A run of correct `stay` decisions does not establish switch-selection accuracy. If no switch has resolved, say that capability is untested.

## Avoid misleading accuracy

- Always show the confusion matrix for the stated disruption threshold: true positives, false positives, true negatives, and false negatives.
- Pair overall accuracy with disruption prevalence and recall. In a mostly normal-flight sample, high accuracy can coexist with zero detected disruptions.
- Do not equate a qualitative `moderate` label with a passenger recommendation to switch unless the decision policy explicitly says so.
- Keep unknown outcomes censored.

## Classify misses by information timing

For every missed disruption, preserve the original snapshot and classify it as one of:

- **Predictable miss:** warning evidence existed at assessment time but was ignored or misinterpreted.
- **Late-developing miss:** the snapshot was clean and a new public signal appeared later.
- **Unobservable event:** no usable public warning appeared before action became impractical.
- **Unresolved cause:** the outcome is known but available evidence cannot establish why it occurred.

Do not convert an unconfirmed cause into fact. A positioned aircraft, normal weather, and normal airport conditions may make an airline-controlled issue more plausible, but the correct wording remains “no confirmed reason.”

## Snapshot timing

A fixed-horizon baseline tests that horizon, not continuous monitoring. A miss caused by a later event may justify a future recheck experiment, but do not retrofit extra snapshots into an active baseline. Test any closer-to-departure cadence as a separately specified model or cohort.

## Minimum project update

Include:

- selected, resolved, pending, and censored counts
- risk-label distribution
- meaningful disruption count and threshold
- confusion matrix or explicit statement that it is not yet informative
- count of frozen stay/switch decisions and how many resolved
- switch cases with verified minutes saved/lost, or “untested”
- provider spend, cap status, collector health, next run, and report date

Lead with the honest decision-quality conclusion, not the largest percentage.
