# Disruption-copilot product strategy

## Positioning

Do not compete with Flighty on polished tracking, maps, or generic alerts. Treat Flighty as the system of awareness and Apollo as the decision and action layer:

> Flighty tells the traveler what changed. Apollo explains what it means, whether to stay or switch, and what to do next.

The differentiating workflow is:

1. Interpret the alert using the exact aircraft, remaining rotation, turns, airport conditions, and time-matched weather.
2. Translate it into personal impact, including connections, deadlines, airport transfers, baggage, status, and risk tolerance.
3. Give a clear `keep`, `prepare`, or `act` recommendation.
4. Ask permission before searching alternatives.
5. If approved, check the airline's disruption/rebooking policy before discussing cash fares.
6. Operationally vet every serious replacement, not merely its schedule and price.
7. Revalidate mutable assignments and fares before recommending.
8. Offer monitoring only with explicit consent.

## Product surface

Use a channel-independent backend. Recommended rollout:

1. **Text-first prototype:** minimal input, screenshots/alerts, conversational follow-up, and immediate push delivery. A personal iMessage bridge is suitable for testing, not production-scale infrastructure.
2. **Production messaging plus mobile web:** use a commercial SMS provider for messaging. Keep the recommendation in text and send secure, expiring web links for dense alternative comparisons, billing, and checkout handoffs.
3. **Native iOS companion after validation:** add a share extension for Flighty alerts/screenshots, itinerary import, push notifications, Live Activities, preferences, and rescue history. Do not assume an iOS app can silently read another app's private data or notifications.

## Revenue patterns

The text thread is the acquisition and service interface; a payment processor handles payment. Never collect card details in chat.

Viable models:

- Per-trip rescue: free health check, paid alternative analysis, and a higher-priced monitoring tier.
- Monthly concierge membership: routine health checks, disruption interpretation, rebooking guidance, vetted alternatives, and opt-in monitoring. This must be positioned as judgment and advocacy, not another tracker.
- B2B2C distribution through premium cards, insurers, corporate travel, OTAs, or travel advisors.

For text subscriptions, send a secure recurring-checkout link after explicit user intent. Map the verified phone/customer ID to the subscription, activate service from a payment webhook, provide receipts and self-service cancellation, and require explicit approval before any future charge made from chat.

## Market benchmark

Flighty is private and does not publish audited revenue. As of July 2026, Sensor Tower's public overview estimated roughly **100,000 worldwide downloads and $800,000 in worldwide App Store revenue for the latest month**. Annualizing that snapshot yields about **$9.6 million gross store revenue**, not company net revenue. Starter Story separately reported approximately **$500,000 monthly revenue**, but its methodology is less transparent. Treat Flighty as an estimated **$7–10 million annual-revenue business**, with wide uncertainty from Apple commissions, refunds, taxes, regional pricing, family plans, and possible web sales. Cite the source and date whenever using this benchmark; do not present it as disclosed financials.

## Defensible value

The moat is decision quality and measured outcomes, not the chatbot UI:

- Prediction-versus-outcome history
- Calibration and false-alarm control
- Aircraft-rotation disruption propagation
- Rebooking success and time saved
- Personalized traveler preferences
- Transparent confirmed facts, unknowns, and evidence-supported inference

Track warning lead time, recommendation acceptance, successful rebooking, minutes saved, fare accuracy, false alarms, cost per traveler, and retention.