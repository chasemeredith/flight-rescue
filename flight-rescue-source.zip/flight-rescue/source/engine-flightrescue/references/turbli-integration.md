# Turbli flight-forecast integration

Use this note with `scripts/turbli_forecast.py` when adding turbulence context to a routine passenger update.

## Request shape

After resolving the exact flight instance, pass:

- Origin and destination as three-letter IATA codes
- Origin-local service date (`YYYY-MM-DD`)
- Boarding-pass flight number, normalized without spaces

Turbli’s predictable flight page is:

`https://turbli.com/{ORIGIN}/{DESTINATION}/{DATE}/{CARRIER}-{NUMBER}/`

Use a browser-like User-Agent. Retry HTTP 429 and transient 5xx responses with bounded backoff; do not repeatedly hammer the site.

## Fields to extract

The flight page currently embeds route-specific values in JavaScript:

- `warning_turb`: Turbli’s plain-language turbulence summary
- `warning_cb`: thunderstorm guidance
- `time`: forecast timestamps along the route
- `CAT`: Turbli’s turbulence/EDR chart values

Never evaluate page JavaScript. Parse only the expected quoted strings and numeric arrays.

Turbli’s displayed chart bands are:

- Light: below 20
- Moderate: 20–39
- Moderate-severe: 40–59
- Severe: 60–79
- Extreme: 80+

For a light forecast, nonzero chart values may span much of the route. Do not describe the entire flight as bumpy. Identify one or two contiguous windows near the route’s forecast peaks, merge points separated by less than roughly 12 minutes, and express timing relative to takeoff. Translate a final window within about 30 minutes of arrival to “during descent.”

## Passenger wording

Keep this to one compact sentence immediately after the aircraft-location/turnaround paragraph:

`Turbli: Light turbulence, mainly 30–50 minutes after takeoff and during descent.`

State the level and approximate timing. Mention thunderstorms only when they materially change expected ride comfort, and then use no more than one additional short sentence. Attribute the forecast to Turbli. Do not imply turbulence is a safety threat or a certainty.

If the forecast page is unavailable, the route/flight does not match, or no forecast is published, omit the section. Never substitute generic airport weather and label it as Turbli data.

## Verification

Run the full skill test suite, then execute the script against a live flight page. Verify:

1. Route/date/flight in the output match the resolved flight.
2. `turbulence` is the page’s actual warning.
3. `timing` is derived from the `time` and `CAT` arrays.
4. The passenger sentence is short and uses relative in-flight timing.
