# Flight risk scoring and calibration

## Current status

`scripts/flight_risk.py` v2 is an explainable qualitative risk rubric with versioned, unique-flight calibration infrastructure. It does not manufacture a probability from the score. Use `low`, `moderate`, `high`, and `severe` as one input to operational judgment, then verify the aircraft rotation, recovery time, live estimate, airports, and weather.

## Required assessment inputs

V2 requires explicit values for:

- Delay already posted for the passenger's flight.
- Delay in the assigned aircraft's upstream rotation.
- Remaining upstream legs.
- Tail status: `confirmed`, `unconfirmed`, or `unassigned`.
- Location confidence: `live`, `actual`, `completed_leg`, `scheduled`, or `unknown`.
- Airport and weather severity, each `0..3`.

A tightest upstream turn and origin recovery buffer are optional when not applicable. Missing required evidence returns an incomplete `unknown` assessment. Invalid, non-finite, negative durations, or wrong-scale values are rejected. Final departure and arrival deviations are signed, so early operation is stored as a negative outcome delay.

## Recovery semantics

Recovery time protects against upstream propagation only. It proportionally mitigates the residual contribution from:

- Upstream rotation delay.
- Remaining upstream legs.
- Tight upstream turns.

It never offsets delay already posted for the passenger's own flight, departure-window airport disruption, weather, assignment uncertainty, or location uncertainty.

The result reports gross, mitigated, and residual points plus plain-language mitigations. Weak points are ranked by residual contribution.

## Prediction identity and horizons

Use a nonblank, provider-scoped physical-flight identifier, preferably `fa_flight_id`, not a reusable marketing number. The first snapshot registers immutable route/date identity metadata; later conflicting snapshots are rejected.

Every recorded prediction stores:

- `model_version`.
- Scheduled departure and minutes to departure when supplied.
- Forecast-horizon bucket.
- Marketing and operating identifiers.
- Origin, destination, and service date when supplied.

Horizon buckets are:

- `under_30m`
- `30m_to_1h`
- `1h_to_3h`
- `3h_to_12h`
- `12h_plus`
- `unknown`
- `post_departure`

Monitoring may retain multiple snapshots. Timestamps are normalized to UTC before storage. Calibration selects only the latest snapshot for each physical flight, model version, and horizon. `post_departure` snapshots remain available operationally but are never treated as predeparture forecasts. Publication thresholds count unique resolved flights, not raw rows.

## Outcomes

Resolve a flight with one explicit status:

- `arrived`
- `cancelled`
- `diverted`
- `returned_to_origin`
- `unknown`

Arrived flights require a signed arrival delay. `unknown` outcomes are censored from every calibration denominator and publication gate. The outcome table separately stores departure delay, arrival delay, on-time arrival, operated-as-planned state, and major disruption. Repeating the same substantive result is idempotent even when a later polling observation has a newer timestamp. Conflicting outcomes require `--correct` and are preserved in an audit table.

Traveler rescue outcomes are stored separately through `rescue-outcome`, including the recommendation, traveler action, replacement flight, minutes saved, and incremental cost. Rescue records require a known physical flight and support an idempotency key. When expected and actual arrival timestamps are supplied, `minutes_saved` is derived or checked against them. This measures Apollo's decision value without contaminating physical-flight calibration.

## Deterministic airport and weather classification

`classify_airport_conditions` maps time-matched average delay, trend, ground stops, and ground-delay programs to severity `0..3`. `classify_weather_conditions` maps thunderstorms, freezing precipitation, visibility, ceiling, and gusts to the same scale. Conditions outside the aircraft's operating window score zero.

Pass a shared event ID when airport congestion and weather describe the same event. The scorer applies a correlation credit so that one thunderstorm is not counted at full weight as both weather and airport disruption.

## Model and schema versions

Current rubric: `flight-risk-v2`.

Legacy rows are migrated to `flight-risk-v1-legacy`. Calibration never combines model versions. The SQLite schema is versioned through `schema_metadata`; connection automatically adds v2 prediction fields and creates outcome/audit tables.

## Probability rules

V2 does not return `raw_probability_internal`, and its Brier score remains `null` because the rubric is not itself a probability forecast.

A calibration bin becomes sample-ready only when:

- The relevant forecast horizon has at least 100 eligible, known-outcome physical flights by default.
- The relevant horizon and score bin has at least 20 unique physical flights by default.
- The outcome is eligible for the reported metric; `unknown` and post-departure observations never qualify.

Sample readiness does not enable publication. Passenger-facing rates remain disabled until documented temporal out-of-sample validation has passed, including reliability/monotonicity review and drift checks. New v2 prediction rows store probability as `NULL`, never a synthetic zero.

Even after those gates, present the value as an observed cohort rate with its confidence interval, not as false precision about one flight. Cancellation and major-disruption calibration should be reported separately as those cohorts accumulate.

## Commands

Qualitative assessment:

```bash
python scripts/flight_risk.py assess \
  --flight-id <fa_flight_id> \
  --scheduled-departure 2026-07-11T12:30:00Z \
  --passenger-flight-delay-minutes 0 \
  --upstream-rotation-delay-minutes 8 \
  --upstream-legs 3 \
  --minimum-turn-minutes 22 \
  --recovery-buffer-minutes 446 \
  --airport-severity 0 \
  --weather-severity 0 \
  --tail-status confirmed \
  --location-confidence live \
  --record
```

Resolve an arrival:

```bash
python scripts/flight_risk.py resolve \
  --flight-id <fa_flight_id> \
  --final-status arrived \
  --departure-delay-minutes 12 \
  --arrival-delay-minutes 8
```

Resolve a cancellation:

```bash
python scripts/flight_risk.py resolve \
  --flight-id <fa_flight_id> \
  --final-status cancelled
```

Record the value of a rescue recommendation:

```bash
python scripts/flight_risk.py rescue-outcome \
  --flight-id <fa_flight_id> \
  --recommendation switch \
  --traveler-action rebooked \
  --idempotency-key <recommendation-event-id> \
  --replacement-flight-id <replacement_fa_flight_id> \
  --minutes-saved 135 \
  --incremental-cost 25 \
  --currency USD
```

Report one calibrated horizon for the current model:

```bash
python scripts/flight_risk.py report \
  --model-version flight-risk-v2 \
  --horizon 1h_to_3h
```

Only after documented holdout validation, the internal report can be run with `--validation-passed`; this switch must not be used merely because sample counts are sufficient.

Default database:

`~/.hermes/data/flight-risk.sqlite`

## Remaining empirical work

The implementation and safety infrastructure are in place. What remains requires real independent outcomes rather than additional structural code:

- Fit risk weights and label boundaries from v2 outcomes.
- Validate the deterministic airport/weather thresholds against observed operations.
- Accumulate enough cancellation and major-disruption outcomes for stable cohorts.
- Measure rescue recommendations by acceptance, minutes saved, and incremental cost.
- Continue validating every published cohort on rolling temporal holdouts and monitor drift.
