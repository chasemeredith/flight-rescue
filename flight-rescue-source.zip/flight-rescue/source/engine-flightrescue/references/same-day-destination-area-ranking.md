# Same-day destination-area flight ranking

Use this when the user wants the best way to reach a city or region today, rather than a literal airport-code search.

## Search scope

- Treat the named airport as the destination area unless the user explicitly requires that runway.
- Search the requested airport and practical commercial alternates. Include ground-transfer time and likely cost.
- Exclude technically nearby fields without useful scheduled service.
- Rank only options the traveler can still realistically book and board.

## Value screen

Build a Pareto comparison across:

- Current fare.
- Door-to-door arrival time, including ground transfer.
- Stops and connection exposure.
- Operational confidence from live aircraft rotations.

Do not call an option “best value” from fare and schedule alone.

## Operational screen before recommending

For every serious candidate:

1. Resolve every flight leg for the correct date.
2. Identify each assigned tail and inspect its complete remaining rotation before the passenger boards it.
3. Calculate aircraft turnaround at every upstream stop.
4. Calculate passenger connection time, terminal/gate movement, and minimum practical buffer.
5. Check active delays and time-matched weather at origin, connection, destination, and relevant upstream airports.
6. Separate “aircraft already at departure airport” from “aircraft has several legs remaining.”
7. Rank operational confidence qualitatively unless a sourced probability model is available.

## Rescue-specific comparison rules

Compare every candidate against the user's **live estimated arrival**, not the original schedule. Calculate the realistic time saved after accounting for:

- The candidate's current estimate.
- Its inbound aircraft's actual delay and remaining legs.
- Turnaround time at the departure airport.
- Connections and terminal movement.
- Ground transfer to a different departure or arrival airport.

Do not trust a candidate's displayed “on-time” estimate when its inbound aircraft is forecast to arrive after departure or leave an implausibly short turn. Call out the mismatch and propagate the inbound risk into the recommendation even if the airline record has not caught up.

Prefer a same-airport option when it offers meaningful improvement. Treat an airport change as a full itinerary leg: estimate travel time, traffic variability, security, baggage handling, and boarding cutoff. Exclude transfers that are merely possible on paper but fragile in practice.

When the best alternative is on the same airline, recommend requesting reaccommodation or a same-day change before suggesting purchase of a new ticket. A search fare is a snapshot; distinguish it from a checkout-verified fare and never imply that the traveler must pay the displayed amount.

## Recommendation pattern

Lead with one decision and one fallback:

- Best overall option and realistic time saved versus the current flight.
- Operational weakness of that option, especially inbound delay or a short turn.
- Best fallback only when it is genuinely useful.
- Excluded nearby-airport options with a short plain-language reason when they looked attractive by schedule but failed operational or transfer checks.

For a disrupted flight, include enough evidence for the traveler to make an informed choice, but omit dominated itineraries. State when assignments, estimates, or fares were last revalidated.