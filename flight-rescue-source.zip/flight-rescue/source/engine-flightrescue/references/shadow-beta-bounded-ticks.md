# Flight Rescue Shadow-Beta Tick Procedure

Use this for bounded, scheduled qualitative-risk data collection where API spend is capped and passenger-facing actions are forbidden.

## Crash-safe sequence

1. Read and preserve the existing state. If absent, initialize the agreed schema before any billable request.
2. Compute due outcomes first. Charge the conservative ledger before each API request, persist that charge atomically, then call the endpoint.
3. For independent requests that will run in parallel, pre-charge the complete batch in one atomic state update. This remains crash-safe because every possible call is already reserved in the ledger.
4. Resolve only final known outcomes. Increment attempts for unresolved records, but never count `unknown` as a resolved calibration outcome.
5. Select candidates only after reserving enough budget for the assessment and a future outcome lookup.
6. Reuse shared origin delay and weather evidence across candidates from the same airport/window. Attribute fractional shared calls in audit data without altering the actual whole-call ledger.
7. Record predictions through `flight_risk.py assess --record` only after the exact physical flight and evidence are verified.
8. Persist the selected-flight state and append one audit event per assessment. Include provider timestamps, scorer inputs/results, due-outcome time, call attribution, and cumulative spend.
9. Verify at tick end: JSON state parses, every JSONL line parses, prediction count matches newly recorded assessments, spend is within cap, and `completed` agrees with state.

## Conservative evidence rules

- A completed inbound at the origin supports `location_confidence=completed_leg` and zero remaining upstream legs.
- A delayed inbound supported only by schedule/estimate uses `location_confidence=scheduled`; retain one remaining upstream leg.
- Use recovery buffer to mitigate upstream delay only. It does not erase delay already posted on the passenger flight.
- Time-match the TAF. Do not score a later thunderstorm window against a morning departure.
- Airport delay severity can be shared only when candidates use the same origin and overlapping operating window.

## Outcome resolution details

- Resolve due records by exact `fa_flight_id`, never by a bare marketing ident.
- Treat `actual_in` as confirmed gate arrival. For arrived flights, calculate signed gate delays from `actual_out - scheduled_out` and `actual_in - scheduled_in`; preserve negative values for early departures/arrivals. Provider delay fields may be used as a cross-check, but persisted minutes should be auditable from timestamps.
- Map cancellation/diversion/return flags and status conservatively. A nonfinal or ambiguous record increments `outcome_attempts` and stays unresolved; reaching the retry limit is exhausted, not a known `unknown` outcome.
- Run `flight_risk.py resolve` before marking state resolved. Then atomically persist the final status, signed delays, resolution timestamp, and provider timestamps, and append the audit event.
- Recompute counters from flight rows after every resolution instead of incrementing cached totals blindly. This keeps retries idempotent and repairs stale counters.

## Audit and reporting

The cron response should report only selected, known resolved, unresolved/exhausted, conservative estimated spend, budget-guard status, and verified completion status. Shadow-mode output must not contain numerical passenger probabilities or trigger fare searches, traveler messaging, purchases, or new jobs.

At tick end, verify state-row count and unique physical IDs, parse every JSONL event, and confirm recorded prediction counts. Inspect the SQLite schema or use the risk CLI's supported report surface before querying tables; do not assume a separate `outcomes` table exists because resolver data may live on prediction rows in some schema versions. A failed optional diagnostic must not invalidate already-verified state, but it should be replaced with a schema-compatible check before claiming database verification.
