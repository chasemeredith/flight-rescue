# Initial-response latency without UX degradation

## Product constraint

Preserve the established single, complete initial flight response. Do not split it into a quick preliminary message plus a later enrichment, remove decision-relevant sections, impose an arbitrary shallow time budget, or make the traveler ask for details that the standard response already includes. Speed improvements belong behind the interface unless the user explicitly requests a different response shape.

## Recommended optimization order

1. Instrument each stage and record p50/p95 latency: flight resolution, live status, tail trace, airport conditions, weather, Turbli, lightweight alternatives, deterministic calculations, and final generation.
2. After exact flight resolution, run independent live lookups concurrently.
3. Consolidate retrieval into one deterministic `flight_brief` operation that deduplicates requests and returns normalized evidence for one reasoning pass.
4. Add conservative TTL caching: airport/timezone/operator metadata long-lived; weather and policy moderately cached; flight status, assignments, rotations, and alternatives briefly cached.
5. Use exact flight IDs, registrations, bounded one-day windows, and one page by default.
6. Move timezone conversion, chronological sorting, turnaround calculations, impossible-turn checks, and alternative timing comparisons out of the model.
7. Reuse HTTP clients and fresh within-request data; avoid repeated model→tool→model loops.
8. Consider precomputed aircraft rotations only after measurements show on-demand reconstruction remains a material bottleneck.

## Target architecture

`traveler message → exact flight resolution → parallel flight_brief aggregation → deterministic risk inputs → one reasoning pass → existing complete response`

## Example targets

Treat these as starting goals, not reasons to degrade completeness:

- Flight resolution under 1 second
- Complete brief under 5 seconds
- Existing response under 8 seconds p50 and 15 seconds p95

## Pitfall

When discussing performance with the user, do not repeatedly propose response fragmentation after they have said the current initial response is the desired product. Show how backend changes preserve that response exactly.