# Delay-cause confidence and rotation-change inference

Use this when a flight is delayed and an inbound aircraft is linked.

## Core distinction

Evidence that an aircraft rotation changed is not automatically evidence that the rotation change caused the delay.

- **Confirmed cause:** A direct airline delay code or statement, or an authoritative airport/ATC notice, explicitly identifies the cause.
- **Likely cause:** Strong flight-specific evidence supports one explanation, but no direct causal source is available.
- **Potential cause:** The evidence permits several plausible explanations.

Never promote an inference to a confirmed cause. A traveler may repeat the explanation to airline staff, so unsupported certainty damages trust.

## Rotation contradiction check

Compare:

1. Passenger flight's original scheduled gate departure.
2. Current inbound aircraft's original scheduled gate arrival.
3. Passenger flight's current estimated departure.
4. Inbound aircraft's current estimated gate arrival.
5. Confirmed physical-aircraft linkage or registration.

If the currently assigned aircraft was originally scheduled to arrive at or after the passenger flight's original departure, that aircraft could not have operated the original schedule. This supports a rotation-change inference even if the inbound is now running early.

Passenger wording:

> The delay is likely due to an aircraft rotation change. The currently assigned plane was originally scheduled to arrive after your scheduled departure, so it could not have operated the original schedule. This supports the explanation, but I cannot confirm the airline's internal delay reason.

Do not claim which original aircraft was removed, where it went, or why the airline changed the rotation without assignment-history evidence.

## Risk versus current impact

State these separately:

- **Current impact:** Delay or disruption already posted.
- **Forward-looking risk:** Chance of additional material worsening, cancellation, diversion, missed turn, or failure to operate.

A modest existing delay does not create moderate or high forward-looking risk when the aircraft is moving, the estimated turn is plausible, and airport/weather conditions are favorable.

## Deterministic helper

Run `scripts/flight_risk.py delay-reason` for delayed flights with a confirmed inbound aircraft. Treat its `likely_*` results as qualified causal inferences, not authoritative delay codes.
