# Cost-capped shadow beta collection

Use this reference when validating the flight-risk model on an automatically selected cohort without exposing experimental recommendations to travelers.

## Purpose

A shadow beta answers whether the model's qualitative judgments correspond to real outcomes. It should measure false alarms, missed disruptions, outcome capture, performance by forecast horizon, factor usefulness, provider-data gaps, and cost per flight. It must not publish numerical probabilities merely because the cohort completed.

## Cohort design

- Select physical flights automatically; never require the user to manually supply the cohort.
- Sample distinct `fa_flight_id` values across multiple airlines, hubs, routes, departure periods, and operating days.
- Avoid filling the cohort with adjacent departures from one airport or one weather event.
- Assess only flights with enough verified evidence to run the deterministic scorer. Log skipped candidates without counting them toward the target.
- Persist route, identifiers, service date, schedule, aircraft registration, inbound flight, scorer inputs/result, evidence timestamps, horizon, and outcome due time.
- Keep traveler delivery, fare search, booking, and continuous monitoring disabled unless separately approved.

## Durable background pattern

1. Use one bounded recurring collector job with persistent JSON/SQLite state and an append-only event log.
2. On each tick, resolve due outcomes first, then select only a small number of new flights.
3. Query narrow time windows with one-page limits and exact physical-flight lookups.
4. Stop selecting after the declared sampling window; continue bounded outcome retries afterward.
5. Treat unknown outcomes as censored. Retry later, cap attempts, and report unresolved cases separately.
6. Deliver routine collector ticks locally/silently. Use a separate one-shot final-report job for the user-facing workbook and summary.
7. Run and inspect the first collector tick immediately. Verify state, event log, prediction records, spend ledger, and next scheduled run before claiming the beta started.

## Hard budget enforcement

- Obtain explicit approval for live provider spend and state the hard cap before enabling collection.
- Maintain a persistent conservative cost ledger by endpoint and charge the ledger *before* each billable call so crashes cannot lose spend.
- Use observed account-specific prices only as estimates; do not present them as universal provider pricing.
- Reserve enough budget for final outcome collection before selecting another flight.
- Set a guard below the absolute cap, not exactly at it. Example: for a $5 cap, stop new calls at $4.75 to retain safety margin.
- Never call an unknown endpoint unless a conservative worst-case price has been reserved.
- Persist the budget-guard state and stop all collection when it triggers.
- Report estimated spend, calls by endpoint, cost per selected flight, and cost per known resolved flight.

## Outcome semantics

- Resolve using the exact stored physical-flight ID.
- Record signed departure and arrival deviations.
- Final known states are arrived, cancelled, diverted, or returned to origin.
- Missing or unknown provider results are not successful flights and must not enter calibration denominators.
- Keep retries idempotent and cap them per flight.

## Final workbook

Create and verify an `.xlsx` with these sheets:

- Summary
- Flights
- Predictions
- Outcomes
- Accuracy
- Factors
- API Usage
- Data Quality

Include filters, frozen headers, useful formatting, charts where justified, and explicit small-sample caveats. Report false alarms, missed major disruptions, capture rate, horizon/risk-label performance, factor frequencies versus outcomes, unresolved cases, duplicates, and provider gaps. Reload the workbook after writing it and verify all required sheets before delivery.

## Pitfalls

- A one-day cohort can validate plumbing but may be dominated by one weather system or airport event.
- Counts alone do not authorize passenger-facing probabilities; temporal holdout validation remains required.
- A scheduled cron entry is not proof of execution. Verify the first live tick and persistent artifacts.
- Do not let routine progress notifications spam the user. Keep worker delivery local and send the final artifact once.
- Do not spend the whole budget on assessments and leave no reserve for outcomes.
