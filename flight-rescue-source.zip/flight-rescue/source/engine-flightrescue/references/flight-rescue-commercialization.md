# Flight Rescue commercialization notes

Use this reference when advising on subscription billing, customer acquisition, or separating Flight Rescue from a personal Hermes installation.

## Subscription payments

Use Stripe-hosted Checkout and Customer Portal rather than collecting card details in chat. Text initiates and explains the purchase; Stripe performs payment; verified webhooks control access.

Recommended production flow:

1. `JOIN` creates a user-bound Checkout Session in subscription mode.
2. Store an internal user ID in `client_reference_id` or metadata.
3. Activate membership only after a verified Stripe webhook, never when the link is sent.
4. Handle at least `checkout.session.completed`, `invoice.paid`, `invoice.payment_failed`, `customer.subscription.updated`, and `customer.subscription.deleted`.
5. Verify webhook signatures and make event processing idempotent.
6. `BILLING` creates a short-lived Customer Portal session for payment updates, invoices, and cancellation.
7. Keep Stripe IDs and subscription state; never store raw card data.

Before charging real users, require clear recurring-price disclosure, terms, privacy, cancellation/refund policy, support contact, separate test/live credentials, and compliant commercial SMS opt-in plus STOP/HELP handling.

## Business and infrastructure separation

A Hermes profile separates config, memory, sessions, skills, and gateway state, but it is not a strong filesystem boundary when it runs under the same OS user. A commercial Flight Rescue deployment should use an Apollo-business-owned cloud account or separate OS boundary with its own:

- Hermes installation and gateway
- model and flight-data credentials
- SMS number/provider
- Stripe account
- database, domain, email, logs, and backups
- narrowly scoped password-manager vault

Migrate only reviewed Flight Rescue assets. Do not clone personal sessions, general memory, `.env`, auth tokens, broad MCP integrations, personal knowledge stores, or unrelated cron jobs. Restrict customer-facing tools; run any necessary terminal access in a container with only the Flight Rescue workspace mounted.

## Marketing sequence

Do not begin with expensive terminal advertising. Validate the message and economics first:

1. Test concise outcome-led copy through search, airport-area mobile ads, travel communities, referrals, and airport-adjacent partners.
2. Geo-target one disruption-prone hub and activate spend when disruption is elevated.
3. Test parking, shuttle, hotel, lounge, rental-car, travel-adviser, or corporate-travel partnerships.
4. Buy official airport digital inventory only after conversion and retention are known.

Physical airport ads must use the official concessionaire; unauthorized signs or solicitation may violate airport rules. Favor airside departure/gate or service-desk contexts over baggage claim. Use a unique QR code or campaign keyword and measure flight submissions, checkout starts, paid conversion, acquisition cost, retention, refunds, and support/API cost.

A useful acquisition funnel is: ad → one useful free assessment → contextual next action → membership offer → `JOIN` → Stripe Checkout. Do not force users to understand the product before seeing its value.

## Budget discipline

At a $9.99 monthly price, customer acquisition must be evaluated against observed retention, payment fees, flight-data cost, messaging, support, refunds, and taxes. Start with a small measured digital test rather than a five-figure airport placement. Establish conversion, retention, and contribution margin before scaling. Treat published advertising benchmarks as directional and obtain current quotes for any airport inventory.
