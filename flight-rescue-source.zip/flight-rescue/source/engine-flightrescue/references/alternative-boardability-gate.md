# Alternative Flight Boardability Gate

Use this during every approved alternatives search before presenting a candidate as actionable.

## Required inputs

- Current timestamp
- Live flight status
- Scheduled or current estimated gate-departure time
- `actual_out`, when available
- Boarding cutoff
- Traveler's current terminal/gate and realistic transit time

## Deterministic rejection order

1. Reject if `actual_out` exists.
2. Reject statuses indicating **left gate**, **taxiing**, **departed**, **airborne**, or **en route**.
3. Reject when departure is at or inside the carrier's boarding cutoff.
4. By default, reject departures under 30 minutes away unless exact gate proximity, cutoff, and physical feasibility are verified.
5. Never recommend a flight under 15 minutes away merely because a tracker or fare search still says `Scheduled`.
6. Re-fetch live status immediately before the final recommendation because pushback can occur between search and response.

Run:

```bash
python3 scripts/flight_risk.py boardability \
  --current-time <RFC3339> \
  --departure-time <RFC3339> \
  --status '<live status>' \
  [--actual-out <RFC3339>]
```

Only candidates returning `"boardable": true` may be framed as flights the traveler can still catch.

## Why this exists

Schedule and fare results are discovery data, not proof of boardability. A flight may show a future scheduled departure after boarding has closed or after the aircraft has pushed back. Filtering on `departure > now` is therefore insufficient.

## Passenger wording

- Rejected: do not present it as an option. If relevant, say it has already closed or left the gate.
- Borderline but exactly verified: state the gate, cutoff, walking constraint, and need to act immediately.
- Viable: distinguish operational viability from seat or fare availability.