# Disruption-copilot product strategy

## Positioning

Do not compete with Flighty on polished tracking, maps, or generic alerts. Treat Flighty as the system of awareness and Apollo as the decision and action layer:

> Flighty tells the traveler what changed. Apollo explains what it means, whether to stay or switch, and what to do next.

The differentiating workflow is:

1. Interpret the alert using the exact aircraft, remaining rotation, turns, airport conditions, time-matched weather, and a lightweight same-route alternatives scan for delayed flights.
2. Translate it into personal impact, including connections, deadlines, airport transfers, baggage, status, and risk tolerance.
3. Give a natural-language recommendation with current impact, forward-looking risk, and a clear practical next step; do not force standardized `keep`, `prepare`, or `act` labels.
4. If no alternative clearly improves the trip, say the current flight still appears best. If a candidate may materially help, name the possibility and ask whether the traveler can catch an earlier flight or wants full investigation. A clear opt-in begins Adapt mode.
5. In Adapt mode, check the airline's disruption/rebooking policy before discussing cash fares.
6. Operationally vet every serious replacement, not merely its schedule and price.
7. Revalidate mutable assignments and fares before recommending.
8. Offer monitoring only with explicit consent.

Preserve one complete initial response. Do not split routine analysis into a shallow first answer and an unsolicited second answer merely to improve perceived speed. Improve latency through instrumentation, parallel collection, bounded exact queries, deduplication, short-lived caching, deterministic calculations, and, when a real backend exists, a consolidated flight-brief operation. Do not mistake a prompt or product-note edit for implemented backend optimization.

## Product surface

Use a channel-independent backend. Recommended rollout:

1. **Text-first prototype:** minimal input, screenshots/alerts, conversational follow-up, and immediate push delivery. A personal iMessage bridge is suitable for testing, not production-scale infrastructure.
2. **Production messaging plus mobile web:** use a commercial SMS provider for messaging. Keep the recommendation in text and send secure, expiring web links for dense alternative comparisons, billing, and checkout handoffs.
3. **Native iOS companion after validation:** add a share extension for Flighty alerts/screenshots, itinerary import, push notifications, Live Activities, preferences, and rescue history. Do not assume an iOS app can silently read another app's private data or notifications.

## Revenue patterns

The text thread is the acquisition and service interface; a payment processor handles payment. Never collect card details in chat.

Viable models:

- Per-trip rescue: free health check, paid alternative analysis, and a higher-priced monitoring tier.
- Monthly concierge membership: routine health checks, disruption interpretation, rebooking guidance, vetted alternatives, and opt-in monitoring. This must be positioned as judgment and advocacy, not another tracker.
- B2B2C distribution through premium cards, insurers, corporate travel, OTAs, or travel advisors.

For text subscriptions, send a secure recurring-checkout link after explicit user intent. Map the verified phone/customer ID to the subscription, activate service from a payment webhook, provide receipts and self-service cancellation, and require explicit approval before any future charge made from chat.

### Stripe implementation sequence

Use Stripe-hosted Checkout and Customer Portal rather than collecting card details or building custom card forms. Start with a single recurring product and test Payment Link for private validation; production should create user-specific Checkout Sessions carrying Apollo's internal user ID. Activate access only after a verified webhook. Handle at minimum checkout completion, successful and failed invoices, subscription updates, and deletion; verify signatures and make event processing idempotent. Generate short-lived portal sessions on `BILLING`. Keep test/live keys and webhook secrets separate. Before public charging, establish recurring-billing disclosure, terms, privacy, cancellation/refund policy, support contact, and compliant commercial SMS handling.

For a US public paid beta, a dedicated single-member LLC, EIN, business bank account, and appropriate liability/technology E&O review are a sensible default; a sole proprietorship may suffice for a small private validation. Form in the actual operating state unless professional advice supports another choice. Apply for the EIN directly through the IRS after entity formation and do not imply that an S-corporation election is required for Stripe.

### Acquisition sequence

Treat official terminal advertising as a later scaling channel, not the first validation channel. Major-airport inventory is controlled, costly, and broad; never place unauthorized signs or conduct commercial solicitation without permission. Validate copy and economics first through disruption-triggered geo-targeted mobile campaigns around one hub, search/social campaigns, travel communities, referrals, and airport-adjacent partners such as parking, shuttles, hotels, lounges, and travel advisers. Then test official digital terminal media near departure boards, gates, or service desks with campaign-specific QR/text attribution. Baggage claim has dwell time but weak intent because the trip has ended.

Airport creative should sell one immediate outcome, not the technical machinery: e.g. “Flight delayed? Find out whether to wait or switch.” Let a traveler submit one flight and experience a useful assessment before presenting membership. Measure text starts, resolved flights, delivered assessments, recommendation engagement, checkout opens, paid conversion, acquisition cost, API/support cost, and first-/third-month retention.

## Market benchmark

Flighty is private and does not publish audited revenue. As of July 2026, Sensor Tower's public overview estimated roughly **100,000 worldwide downloads and $800,000 in worldwide App Store revenue for the latest month**. Annualizing that snapshot yields about **$9.6 million gross store revenue**, not company net revenue. Starter Story separately reported approximately **$500,000 monthly revenue**, but its methodology is less transparent. Treat Flighty as an estimated **$7–10 million annual-revenue business**, with wide uncertainty from Apple commissions, refunds, taxes, regional pricing, family plans, and possible web sales. Cite the source and date whenever using this benchmark; do not present it as disclosed financials.

## Defensible value

The moat is decision quality and measured outcomes, not the chatbot UI:

- Prediction-versus-outcome history
- Calibration and false-alarm control
- Aircraft-rotation disruption propagation
- Rebooking success and time saved
- Personalized traveler preferences
- Transparent confirmed facts, unknowns, and evidence-supported inference

Track warning lead time, recommendation acceptance, successful rebooking, minutes saved, fare accuracy, false alarms, cost per traveler, and retention.