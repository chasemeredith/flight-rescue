# Lightweight Alternatives Scan

Use this before the first passenger-facing response for every delayed flight. It is a triage screen, not Adapt mode.

## Purpose

Answer one narrow question: does another plausible flight appear capable of delivering the traveler materially earlier or more reliably than the current flight?

## Procedure

1. Search same-origin, same-destination nonstop departures after the current time.
2. Compare each candidate against the disrupted flight’s **live feasible arrival**, not its published schedule.
3. Remove departed, overnight, dominated, wrong-route, and operationally impossible options.
4. Use live flight status as schedule truth. Fare-search departure times can lag a newly posted delay.
5. Check only enough operational data to reject obvious traps: assigned aircraft location, remaining inbound legs, and whether the origin turnaround is plausible.
6. Do not deeply verify fares, connections, nearby airports, baggage, booking terms, or every upstream turn during this scan.

## Initial-response wording

- No candidate clearly improves the trip: **“This still appears to be your best option.”**
- A candidate may materially improve the trip: **“There may be better options. Do you want me to look into those?”**

Do not name a candidate as a firm recommendation from the lightweight scan alone.

## Adapt handoff

A clear yes begins Adapt mode. Then:

1. Deeply vet the best two or three candidates: live timing, aircraft rotation, every relevant turn, airport/weather exposure, connections, fare and restrictions.
2. Present the best specific candidate and ask whether the traveler wants it.
3. Once the traveler expresses interest in that flight, ask only **“Do you have any checked baggage?”** and wait. This hard gate applies to same-airline and cross-airline changes. Do not run more searches, revalidate, open booking pages, provide links, or advise cancellation or purchase until the baggage workflow is complete.
4. After a **no-bag** answer, revalidate the selected flight and provide a verified booking or protected-rebooking handoff. Never claim a seat or reservation change unless the airline confirms it.
5. After a **checked-bag** answer, require confirmation from the current airline that the bag can be retrieved or rerouted in time before recommending purchase, cancellation, or completing the switch.
6. Test any booking handoff URL. If an airline page is blocked or generic, use a tested route/date-specific Google Flights or metasearch URL and state the exact flight and fare to select. A generic Manage Trips page may be identified as a rebooking portal, never as a direct itinerary link.
7. Treat prices as snapshots and never substitute stale fare-search timing for live operational timing.
