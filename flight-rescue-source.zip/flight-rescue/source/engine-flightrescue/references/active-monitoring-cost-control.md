# Active flight monitoring and cost control

Use this reference when designing a watcher for tail swaps, status changes, ETA movement, cancellations, or changed rebooking recommendations.

## Architecture

1. Resolve and persist the exact `fa_flight_id`, marketing ident, operating ident, registration, route, scheduled times, and last estimates.
2. Use a deterministic script-only watcher for routine checks. Do not invoke an LLM when nothing changed.
3. Poll the exact flight record first. Compare registration, inbound `fa_flight_id`, status, cancellation/diversion flags, and estimated gate times against saved state.
4. Stay silent when there is no material change.
5. On a tail swap or meaningful status/ETA change, fetch the new tail rotation, reassess the recommendation, and send one concise notification.
6. Stop automatically after departure/arrival, cancellation, expiry, or a maximum-check/spend threshold.
7. Read the provider's free account-usage endpoint before and after tests when available. Enforce a per-watch budget and report it.

## Monitoring modes

- **Snapshot:** Revalidate immediately before the recommendation, label it `Verified <local timestamp>`, and do not monitor afterward.
- **Watch:** Only after explicit user approval, monitor until the declared stopping condition. Notify on material changes only; never send repetitive “no change” messages.

A cost-conscious adaptive cadence is usually better than constant high frequency:

- Poll every 30 minutes when departure is several hours away.
- Tighten to every 10–15 minutes near departure or while a critical inbound leg is active.
- Prefer event/push alerts for supported status events, but do not assume they report tail swaps. Retain low-frequency exact-flight polling when registration changes matter.

## Cost model

Pricing is account-, tier-, endpoint-, page-, and date-dependent. Never hard-code these figures as universal prices. Query the live usage meter or pricing portal before quoting costs.

Observed on one AeroAPI account in July 2026:

- `GET /flights/{ident}`: $0.005 per returned page.
- `GET /airports/{id}/delays`: $0.01 per page.
- `GET /flights/{id}/position`: $0.01 per call.
- Weather calls: approximately $0.003–$0.005 in the observed aggregate.
- `GET /account/usage`: reported as zero-cost by FlightAware support.

At the observed rate, a six-hour watcher costs approximately:

| Cadence | Checks | Exact-flight only | Flight + tail rotation every check |
|---|---:|---:|---:|
| 30 minutes | 12 | $0.06 | $0.12 |
| 15 minutes | 24 | $0.12 | $0.24 |
| 10 minutes | 36 | $0.18 | $0.36 |
| 5 minutes | 72 | $0.36 | $0.72 |

An adaptive six-hour schedule of every 30 minutes for four hours and every 10 minutes for the final two hours makes 20 checks: about $0.10 for exact-flight checks or $0.20 if the full rotation is fetched every time at those observed rates.

## Cost pitfalls

- Provider charges can be per page/result set, not merely per HTTP request. Cap pages and use narrow date windows.
- A full operational reassessment costs more than a registration check because it may include the flight, tail rotation, positions, airport delays, and weather.
- Push-alert callbacks may themselves be billable and may have active-alert limits by plan.
- Agent/model tokens are separate from flight-data API fees. A script-only unchanged check should use no model tokens.
- Google Flights or other fare searches have a separate cost model and should not be conflated with AeroAPI charges.
- Always distinguish a measured account rate from a provider-wide promise; pricing can change.
