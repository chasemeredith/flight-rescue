# Current impact vs. forward-looking disruption risk

Use this distinction in every passenger-facing flight assessment.

## Two separate judgments

1. **Current impact**: what has already happened or is currently posted, such as a 40-minute delay, cancellation, missed connection, diversion, or gate return.
2. **Forward-looking risk**: the chance that conditions worsen materially from the current estimate, such as a further delay, impossible turnaround, cancellation, diversion, missed connection, or failure to operate.

A modest posted delay does not automatically imply moderate or high forward risk. If the assigned aircraft is moving, its estimated arrival supports a plausible turnaround, airport operations are normal, and relevant weather is benign, describe the delay plainly and call the risk of further disruption low. Do not use standardized KEEP/PREPARE/ACT prefixes; lead naturally with the flight status and practical implication.

## Explaining an early inbound with a delayed outbound

“Early” is relative to the inbound flight’s own schedule. Compare all four gate times:

- inbound scheduled arrival
- inbound estimated arrival
- passenger flight scheduled departure
- passenger flight estimated departure

An inbound can arrive early relative to its schedule yet still arrive too late to operate the outbound on time. Example: inbound scheduled at 10:11, now estimated 9:52; outbound scheduled 9:55, now estimated 10:35. The inbound is 19 minutes early, but the original outbound departure remains impossible because only three minutes separate gate arrival and scheduled departure. The new estimate provides a realistic 43-minute turn.

This pattern can indicate an aircraft reassignment or disrupted rotation, but current-state APIs generally do not prove prior assignment history. Say a swap is plausible, not confirmed, unless timestamped assignment history identifies the original aircraft. Never invent the prior tail or claim it was “pulled elsewhere” without evidence.
