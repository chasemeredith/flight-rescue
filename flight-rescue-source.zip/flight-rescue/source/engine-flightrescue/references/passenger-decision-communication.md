# Passenger decision communication

Use this guide to turn detailed operational analysis into a useful traveler-facing answer.

## Match detail to the decision

### Healthy single flight

Lead with “looks good” or “I would keep it.” Include only:

- Where the assigned aircraft is now.
- When it should reach the traveler’s origin.
- The resulting turnaround or overnight recovery buffer.
- Estimated departure and destination arrival, with timezone abbreviations.
- One short confirmation that weather and airport operations were checked and look normal.
- Verification timestamp.

Do not dump raw weather, airport statistics, risk factors, or the full aircraft history unless the user asks.

Example:

> **AS469 looks good.**
>
> Your assigned plane, a Boeing 737-900 (**aircraft ID N264AK**), is airborne from PDX and should reach BNA around **5:07 PM CDT**. That leaves a healthy **1h 03m turnaround** before your estimated **6:10 PM CDT** departure. Weather and airport operations at BNA and SEA look normal. Estimated SEA arrival: **8:59 PM PDT**.

### Materially disrupted flight

Add only the evidence that changes the decision:

- Current delay and live arrival estimate.
- Remaining upstream legs and tightest relevant turn.
- Confirmed cause, or “I couldn’t find a confirmed reason” followed by clearly labeled likely contributors.
- Clear action: keep, watch, or consider alternatives.

If alternatives may help, end by asking whether the traveler wants you to start searching. Do not begin the search until they clearly say yes.

### Alternative-flight decision

Use a layered comparison:

1. Best recommendation and fallback.
2. Compact comparison of all viable options.
3. Tail/rotation detail for each serious option.
4. Excluded options and why.
5. Unconfirmed fares, assignments, or causes.

For same-airline alternatives, check the carrier’s current disruption policy before discussing a cash fare. Tell the traveler to use the airline’s protected rebooking flow first; a metasearch price is irrelevant until the carrier refuses a free/protected change.

## Explain aircraft identifiers

Never lead with an unexplained registration such as `N264AK`. On first mention use:

> Your assigned plane, a Boeing 737-900 (**aircraft ID N264AK**), ...

Then call it “your plane.” The identifier remains useful for exact-aircraft tracking without requiring aviation knowledge.

## Search discipline

When alternatives are requested:

1. Search same-origin, same-destination nonstops first.
2. Vet the strongest same-airport candidate before expanding.
3. Search nearby airports or connections only when no same-airport option is viable or the potential savings justify the transfer.
4. Never begin with broad `stops:any` searches across several airports.
5. Revalidate the recommended flight’s tail, inbound flight ID, fare, and carrier rebooking eligibility immediately before responding.

## Recovery buffers

Judge risk at the traveler’s departure, not at every intermediate turn in isolation. A tight upstream turn can delay the positioning chain, but a long sit at the traveler’s origin may absorb it. Pass the origin recovery time into `flight_risk.py --recovery-buffer-minutes`.

For overnight-originating flights, worry primarily when:

- The final positioning leg is cancelled or diverted.
- The tail assignment changes without a healthy replacement.
- The aircraft has not reached the origin late enough that the remaining ground time threatens servicing, crew, or the passenger departure.

Do not call a next-morning flight moderate risk solely because an earlier intermediate turn is tight when the aircraft is scheduled to sit at the origin for many hours.