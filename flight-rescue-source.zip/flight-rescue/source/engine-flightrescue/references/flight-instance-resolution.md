# Flight-instance resolution fallback

Use this when a boarding-pass flight number returns no live records or multiple records near midnight.

## Resolution sequence

1. Confirm the traveler’s date in ordinary language.
2. Interpret that date at the departure airport. “Today” is an origin-local service date, not a UTC date.
3. Query a UTC window wide enough to include the complete origin-local day. A late US departure may have `scheduled_out` on the following UTC date.
4. Search the marketing/IATA ident first, then the operating/ICAO form when known.
5. Match `ident_iata` and `codeshares_iata`; retain the exact `fa_flight_id`.
6. If live results are empty, query schedules using carrier + flight number + date. Never search the number alone and accept another airline’s flight.
7. Filter candidates by origin-local departure date, carrier, route, and departure time.
8. If one candidate remains, continue automatically. If none or several remain, ask for origin and destination or a screenshot.

## Failure pattern to avoid

An empty live lookup does not prove the flight is absent. It may reflect IATA/ICAO translation, a schedule-only record, UTC date rollover, a codeshare, or a provider gap. Do not state that the flight does not operate until the fallback sequence is exhausted.

## Verification

Before tracing the aircraft, confirm:

- Passenger-facing flight number
- Origin and destination
- Origin-local service date
- Operating ident
- Stable physical `fa_flight_id`
- Assigned registration, if available
