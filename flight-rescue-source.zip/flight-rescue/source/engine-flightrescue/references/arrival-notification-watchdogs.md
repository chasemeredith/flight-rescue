# Arrival Notification Watchdogs

Use this pattern when a user wants a message near a flight's landing or gate-arrival time.

## Preferred pattern

1. Fetch the exact live flight instance and its current estimated landing (`estimated_on`) and gate-arrival (`estimated_in`) times.
2. If the user says “when it lands,” schedule one one-shot check at `estimated_on` or 1–2 minutes afterward. If they care about pickup or deplaning, target `estimated_in` instead.
3. Make the scheduled prompt self-contained: flight ident, date, route, expected status fields, and delivery destination.
4. At execution, report only the state actually confirmed: airborne, landed/taxiing, or arrived at gate. Include actual times when available.
5. If still airborne, provide the updated ETA. Do not recursively schedule more checks from the cron run.

## Cadence rule

Do not default to recurring checks every few minutes. Frequent polling is appropriate only when the user explicitly asks for continuous tracking or unusually tight operational monitoring. For ordinary loved-one arrival reassurance, an ETA-targeted one-shot check is lower-noise and sufficient.

## Cancellation rule

When asked to stop tracking:

1. List jobs to discover IDs rather than guessing.
2. Remove every job whose name or prompt is tied to the flight.
3. Re-list or otherwise verify no related job remains.
4. Preserve unrelated scheduled jobs.

## Language and state precision

- `actual_on` means runway landing.
- `actual_in` means gate arrival.
- Say “the flight has landed” when only landing is confirmed.
- Avoid claiming a traveler is personally safe based solely on aircraft telemetry.
