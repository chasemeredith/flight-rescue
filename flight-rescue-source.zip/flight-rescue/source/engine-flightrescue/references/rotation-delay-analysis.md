# Rotation and Delay Analysis

## Worked method

For a flight whose assigned aircraft is known:

1. Fetch the passenger flight and capture its registration and inbound `fa_flight_id`.
2. Query recent and upcoming flights for that registration.
3. Filter by the origin-local service date and sort chronologically.
4. Establish the aircraft’s physical location from live position or actual movement data.
5. Walk every linked leg forward to the passenger flight.
6. At each stop, record actual/estimated gate arrival, next gate departure, turnaround, airport restrictions, and time-matched weather.
7. Separate gross upstream exposure from the risk that remains after actual progress and recovery.

## Gross exposure versus residual risk

A tight turn is a potential propagation event, not a permanent property of the later passenger flight.

- Score the delay projected into the final positioning leg, not the worst raw delay seen several legs earlier.
- Credit later legs that completed normally and any real recovery window before the passenger flight.
- An overnight buffer of several hours can fully retire an earlier turn or delay as a current weak point.
- Once fully mitigated, remove that factor from `weak_points` and from passenger-facing “main concern” language.
- The remaining risk is whether the aircraft completes its final positioning leg, plus supported crew, maintenance, assignment, airport, or weather uncertainty.
- Recovery never erases delay already posted for the passenger’s own flight.

### Regression example

An aircraft has a 26-minute turn several legs upstream, is projected to reach the passenger’s origin only 10 minutes late, then sits for 7 hours 25 minutes overnight. The early turn’s gross exposure is real historically, but its residual contribution to the morning flight is zero. Calling it the morning flight’s “main concern” is an analysis error.

## Plausibility checks for live estimates

Do not blindly repeat tracker estimates:

- Compute `inbound estimated gate arrival → passenger estimated gate departure`.
- If the displayed turn is operationally impossible, say so plainly.
- Estimate a cautious earliest feasible departure using a plausible turn range for that operator and aircraft.
- Distinguish runway landing from gate arrival; the turn begins at the gate.
- Recheck the exact flight and assignment immediately before recommending action.

Example: an inbound is expected at 7:50 PM while the passenger departure still shows 7:56 PM. A six-minute gate turn is not plausible. The posted estimate is stale even if the status still says “scheduled.”

## Interpretation rules

- An airborne aircraft with a generous turn is stronger evidence than a generic scheduled status.
- A scheduled inbound that has not departed carries more uncertainty.
- Multiple upstream legs create propagation opportunities, but count only their remaining effect after recovery.
- A 30–40 minute turn can be routine for Southwest-style operations but is less resilient than 60+ minutes.
- Weather outside the aircraft’s operating window should not be presented as current flight risk.
- If the plane arrived early but its next leg left late, aircraft positioning does not establish the cause.

## Recommended phrasing

- “I traced the assigned aircraft through its full rotation.”
- “That earlier turn has been absorbed by the overnight recovery window.”
- “The remaining risk is whether the plane completes its final positioning flight.”
- “The posted departure assumes only six minutes at the gate, which is not operationally plausible.”
- “I couldn’t find a confirmed reason for the delay.”
