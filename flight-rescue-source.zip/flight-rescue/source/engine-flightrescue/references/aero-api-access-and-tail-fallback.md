# Aero API access and tail-number fallback

## What this session showed

- The Aero credential may exist in 1Password and still not be enough to read history/rotation if the account tier is too low.
- A hidden tail number on FlightAware does not by itself mean the tail is unknowable; first verify whether an AeroAPI or equivalent operational source is configured.
- If the configured Aero source returns `INVALID_API_KEY`, `401`, or explicit tier gating such as historical/Foresight access restrictions, treat that as an access problem rather than a data absence problem.
- Do not downgrade to a short status-only response just because the tail is gated. Keep the standard full Flight Rescue structure and mark the tail/rotation line as unavailable only after checking the operational source.

## Debug path used here

1. Confirm the 1Password bridge exists for the flight tooling.
2. Confirm the Aero credential item exists in the vault.
3. Verify the local CLI can read the credential.
4. Run the CLI doctor check.
5. If the doctor passes auth but the flight call returns tier/permission errors, stop and classify it as insufficient access.

## Useful signals

- `Upgrade account to see tail number` on the live page means the UI is hiding the field.
- `INVALID_API_KEY` can mean the key is wrong, but it can also mean the account lacks the endpoint tier needed for the call.
- Historical flight traces and Foresight-like predictions may require a different tier from basic live status.
