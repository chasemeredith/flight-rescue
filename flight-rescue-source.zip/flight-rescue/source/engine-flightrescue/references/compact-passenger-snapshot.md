# Compact Passenger Flight Snapshot

Use this structure for routine flight assessments. Keep each bullet to one operational fact.

```text
<Flight>, <ORIGIN> → <DESTINATION>, is <status/delay>. Aircraft: <plain-language type>.

- Scheduled departure: <time + origin timezone>
- Estimated departure: <time + origin timezone>, Gate <gate>
- Estimated arrival: <time + destination timezone>, Gate <gate>
- The assigned plane is <confirmed current location/status>
- Before this flight it must operate <all remaining legs>; expected at origin <time>, leaving a <minutes>-minute turnaround

<Confirmed/likely/potential reason with evidence and confidence caveat.>
<Delay expected to hold/grow/shrink by X–Y minutes, plus the specific weak point.>
Turbulence: <level, timing, and only a material thunderstorm caveat.>
Weather: <one concise line covering only operationally relevant origin/destination conditions.>

Recommendation: <keep/watch/switch in natural language>. <One-sentence explanation incorporating the lightweight alternatives result.>

Verified at <origin-local time>.
```

## Compression rule

Default to this compact presentation for routine passenger updates. Do not prepend a long decision framework, assumptions section, trigger list, monitoring explanation, or product commentary unless the traveler asks for that depth. Remove repetition, generic explanation, raw tracker detail, and irrelevant green conditions. Preserve identity/type, delay, times/gates, every remaining upstream leg, turnaround, turbulence, material weather, and the decision.

Place `Recommendation:` near the end, immediately before the verified timestamp. Keep its explanation to one or two short sentences. If the current flight remains best, say so there rather than adding a separate alternatives section. If a better option may exist, use the recommendation line to ask whether the traveler wants it investigated.

## Adapt trigger

Run a lightweight same-route alternatives scan for every delayed flight before the initial response. This scan compares plausible departure and realistic arrival times only; it does not deeply trace aircraft, verify fares, or recommend a purchase. If nothing clearly improves the trip, say the current flight still appears best. If a better option may exist, ask whether the traveler wants a full investigation. Only that opt-in begins Adapt mode and authorizes full fare, aircraft-rotation, connection, and booking verification.
