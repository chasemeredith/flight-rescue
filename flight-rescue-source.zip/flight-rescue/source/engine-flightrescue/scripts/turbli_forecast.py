#!/usr/bin/env python3
"""Fetch and summarize Turbli's route-specific turbulence forecast.

Usage:
  python turbli_forecast.py --origin BNA --destination SLC \
      --date 2026-07-11 --flight DL2205

The script uses only the Python standard library and emits JSON. Turbli forecasts
are advisory snapshots, not safety guarantees or substitutes for crew guidance.
"""

from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import math
import re
import time
from dataclasses import asdict, dataclass
from typing import Callable
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

BASE_URL = "https://turbli.com"
USER_AGENT = (
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) "
    "AppleWebKit/537.36 Chrome/124 Safari/537.36"
)


@dataclass
class TurbliForecast:
    available: bool
    flight: str
    origin: str
    destination: str
    date: str
    turbulence: str | None
    thunderstorms: str | None
    turbulence_windows: list[dict[str, object]]
    timing: str | None
    source_url: str
    fetched_at: str
    error: str | None = None


def normalize_flight(value: str) -> tuple[str, str]:
    compact = re.sub(r"[^A-Za-z0-9]", "", value).upper()
    match = re.fullmatch(r"([A-Z][A-Z0-9]?|[A-Z]{3})(\d{1,4}[A-Z]?)", compact)
    if not match:
        raise ValueError(f"Invalid flight number: {value!r}")
    carrier, number = match.groups()
    return compact, f"{carrier}-{number}"


def build_url(origin: str, destination: str, date: str, flight: str) -> str:
    origin = origin.strip().upper()
    destination = destination.strip().upper()
    if not re.fullmatch(r"[A-Z]{3}", origin) or not re.fullmatch(r"[A-Z]{3}", destination):
        raise ValueError("Origin and destination must be three-letter IATA codes")
    dt.date.fromisoformat(date)
    _, slug = normalize_flight(flight)
    return f"{BASE_URL}/{origin}/{destination}/{date}/{slug}/"


def _decode_js_string(value: str) -> str:
    value = html.unescape(value)
    return (
        value.replace(r"\"", '"')
        .replace(r"\'", "'")
        .replace(r"\\", "\\")
        .strip()
    )


def parse_forecast_page(page: str) -> tuple[str | None, str | None]:
    def variable(name: str) -> str | None:
        pattern = rf'var\s+{re.escape(name)}\s*=\s*\("((?:\\.|[^"\\])*)"\)\.substring'
        match = re.search(pattern, page)
        return _decode_js_string(match.group(1)) if match else None

    turbulence = variable("warning_turb")
    thunderstorms = variable("warning_cb")
    if turbulence in {None, "", "0"}:
        turbulence = None
    if thunderstorms in {None, "", "0"}:
        thunderstorms = None
    return turbulence, thunderstorms


def _numeric_array(page: str, name: str) -> list[float]:
    patterns = [
        rf'var\s+{re.escape(name)}\s*=\s*(\[[\s\S]*?\])\s*;',
        rf'var\s+{re.escape(name)}\s*=\s*\("(\[[\s\S]*?\])"\)\.substring',
    ]
    for pattern in patterns:
        match = re.search(pattern, page)
        if match:
            values = json.loads(html.unescape(match.group(1)))
            return [float(value) for value in values]
    return []


def _format_minutes(minutes: float) -> str:
    rounded = max(0, int(5 * round(minutes / 5)))
    if rounded < 60:
        return f"{rounded} min"
    hours, remainder = divmod(rounded, 60)
    return f"{hours}h" if remainder == 0 else f"{hours}h {remainder}m"


def turbulence_timing(page: str) -> tuple[list[dict[str, object]], str | None]:
    """Find up to two meaningful bump windows on Turbli's time/EDR chart."""
    times = _numeric_array(page, "time")
    edr = _numeric_array(page, "CAT")
    if len(times) != len(edr) or len(times) < 2 or not edr:
        return [], None
    peak = max(edr)
    if not math.isfinite(peak) or peak < 8:
        return [], None

    # Turbli's chart bands are light <20, moderate <40, mod-severe <60,
    # severe <80. For light forecasts, select areas near the route peak rather
    # than misleadingly describing every non-zero chart point as bumpy.
    threshold = max(8.0, peak * 0.72)
    selected = [index for index, value in enumerate(edr) if value >= threshold]
    groups: list[list[int]] = []
    for index in selected:
        if not groups or times[index] - times[groups[-1][-1]] > 12 * 60:
            groups.append([index])
        else:
            groups[-1].append(index)

    def level(value: float) -> str:
        if value < 20:
            return "light"
        if value < 40:
            return "moderate"
        if value < 60:
            return "moderate-severe"
        if value < 80:
            return "severe"
        return "extreme"

    start_epoch = times[0]
    total_minutes = (times[-1] - start_epoch) / 60
    windows: list[dict[str, object]] = []
    for group in groups:
        start = (times[group[0]] - start_epoch) / 60
        end = (times[group[-1]] - start_epoch) / 60
        group_peak = max(edr[index] for index in group)
        windows.append({
            "start_minutes": round(start),
            "end_minutes": round(end),
            "level": level(group_peak),
            "peak": round(group_peak, 1),
        })
    windows.sort(key=lambda item: float(item["peak"]), reverse=True)
    windows = sorted(windows[:2], key=lambda item: float(item["start_minutes"]))

    phrases = []
    for window in windows:
        start = float(window["start_minutes"])
        end = float(window["end_minutes"])
        if start >= total_minutes - 30:
            phrase = "during descent"
        elif end <= 25:
            phrase = "shortly after takeoff"
        elif end - start < 8:
            phrase = f"around {_format_minutes((start + end) / 2)} after takeoff"
        else:
            phrase = f"about {_format_minutes(start)}–{_format_minutes(end)} after takeoff"
        phrases.append(phrase)
    return windows, " and ".join(dict.fromkeys(phrases)) or None


def fetch_html(url: str, attempts: int = 3, sleep: Callable[[float], None] = time.sleep) -> str:
    headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml"}
    last_error: Exception | None = None
    for attempt in range(attempts):
        try:
            with urlopen(Request(url, headers=headers), timeout=30) as response:
                return response.read().decode("utf-8", "replace")
        except HTTPError as exc:
            last_error = exc
            if exc.code not in {429, 500, 502, 503, 504} or attempt == attempts - 1:
                raise
            retry_after = exc.headers.get("Retry-After")
            delay = float(retry_after) if retry_after and retry_after.isdigit() else 5.0 * (attempt + 1)
            sleep(delay)
        except URLError as exc:
            last_error = exc
            if attempt == attempts - 1:
                raise
            sleep(2.0 * (attempt + 1))
    raise RuntimeError(f"Unable to fetch Turbli: {last_error}")


def get_forecast(origin: str, destination: str, date: str, flight: str) -> TurbliForecast:
    compact, _ = normalize_flight(flight)
    origin, destination = origin.upper(), destination.upper()
    url = build_url(origin, destination, date, compact)
    fetched_at = dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")
    try:
        page = fetch_html(url)
        turbulence, thunderstorms = parse_forecast_page(page)
        windows, timing = turbulence_timing(page)
        if not turbulence:
            return TurbliForecast(
                False, compact, origin, destination, date, None, None, [], None,
                url, fetched_at, "Turbli did not publish a forecast for this flight",
            )
        return TurbliForecast(
            True, compact, origin, destination, date, turbulence, thunderstorms,
            windows, timing, url, fetched_at,
        )
    except (HTTPError, URLError, TimeoutError) as exc:
        return TurbliForecast(
            False, compact, origin, destination, date, None, None, [], None,
            url, fetched_at, f"Turbli request failed: {exc}",
        )


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--origin", required=True)
    parser.add_argument("--destination", required=True)
    parser.add_argument("--date", required=True)
    parser.add_argument("--flight", required=True)
    args = parser.parse_args()
    forecast = get_forecast(args.origin, args.destination, args.date, args.flight)
    print(json.dumps(asdict(forecast), ensure_ascii=False))
    return 0 if forecast.available else 2


if __name__ == "__main__":
    raise SystemExit(main())
