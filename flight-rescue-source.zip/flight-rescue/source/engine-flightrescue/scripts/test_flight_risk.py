#!/usr/bin/env python3
import importlib.util
import json
import math
import sqlite3
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path

MODULE_PATH = Path(__file__).with_name("flight_risk.py")
spec = importlib.util.spec_from_file_location("flight_risk", MODULE_PATH)
flight_risk = importlib.util.module_from_spec(spec)
assert spec.loader
spec.loader.exec_module(flight_risk)


def healthy(**overrides):
    data = {
        "passenger_flight_delay_minutes": 0,
        "upstream_rotation_delay_minutes": 0,
        "upstream_legs": 0,
        "minimum_turn_minutes": 75,
        "recovery_buffer_minutes": None,
        "airport_severity": 0,
        "weather_severity": 0,
        "historical_on_time_rate": None,
        "historical_sample": 0,
        "tail_status": "confirmed",
        "location_confidence": "actual",
    }
    data.update(overrides)
    return data


class ScoringTests(unittest.TestCase):
    def test_low_risk_flight(self):
        result = flight_risk.score_flight(healthy())
        self.assertTrue(result["assessment_complete"])
        self.assertEqual(result["risk_score"], 0)
        self.assertEqual(result["risk_label"], "low")
        self.assertNotIn("raw_probability_internal", result)

    def test_missing_evidence_is_unknown(self):
        result = flight_risk.score_flight({})
        self.assertFalse(result["assessment_complete"])
        self.assertEqual(result["risk_label"], "unknown")
        self.assertIsNone(result["risk_score"])
        self.assertIn("tail_status", result["missing_inputs"])

    def test_passenger_delay_is_not_offset_by_recovery(self):
        result = flight_risk.score_flight(healthy(
            passenger_flight_delay_minutes=90,
            recovery_buffer_minutes=420,
        ))
        self.assertEqual(result["risk_score"], 30)
        self.assertEqual(result["risk_label"], "moderate")
        self.assertEqual(result["mitigations"], [])

    def test_long_recovery_mitigates_only_upstream_risk(self):
        result = flight_risk.score_flight(healthy(
            upstream_rotation_delay_minutes=8,
            upstream_legs=3,
            minimum_turn_minutes=22,
            recovery_buffer_minutes=446,
            location_confidence="live",
        ))
        self.assertEqual(result["risk_score"], 0)
        self.assertEqual(result["risk_label"], "low")
        self.assertTrue(result["mitigations"])
        turn = next(f for f in result["factors"] if f["factor"] == "minimum_turn")
        self.assertEqual(turn["residual_points"], 0)
        self.assertNotIn("a tight upstream turnaround", result["weak_points"])
        self.assertNotIn("minimum_turn", result["passenger_wording"])

    def test_unknown_tail_and_location_are_penalized(self):
        result = flight_risk.score_flight(healthy(tail_status="unassigned", location_confidence="unknown"))
        self.assertEqual(result["risk_score"], 24)
        self.assertEqual(result["risk_label"], "moderate")

    def test_label_boundaries(self):
        self.assertEqual(flight_risk.risk_label(19), "low")
        self.assertEqual(flight_risk.risk_label(20), "moderate")
        self.assertEqual(flight_risk.risk_label(39), "moderate")
        self.assertEqual(flight_risk.risk_label(40), "high")
        self.assertEqual(flight_risk.risk_label(59), "high")
        self.assertEqual(flight_risk.risk_label(60), "severe")
        self.assertEqual(flight_risk.risk_label(100), "severe")

    def test_invalid_values_are_rejected(self):
        bad_cases = [
            {"passenger_flight_delay_minutes": math.nan},
            {"upstream_rotation_delay_minutes": math.inf},
            {"minimum_turn_minutes": -1},
            {"recovery_buffer_minutes": -1},
            {"historical_on_time_rate": 80, "historical_sample": 100},
            {"upstream_legs": 1.5},
            {"airport_severity": 4},
        ]
        for override in bad_cases:
            with self.subTest(override=override), self.assertRaises(ValueError):
                flight_risk.score_flight(healthy(**override))

    def test_deterministic_condition_classifiers_and_correlation_cap(self):
        airport = flight_risk.classify_airport_conditions(
            average_delay_minutes=53, trend="decreasing", event_id="CLT-TS-1"
        )
        weather = flight_risk.classify_weather_conditions(
            thunderstorm=True, event_id="CLT-TS-1"
        )
        self.assertEqual(airport["severity"], 1)
        self.assertEqual(weather["severity"], 2)
        result = flight_risk.score_flight(healthy(
            airport_severity=airport["severity"], weather_severity=weather["severity"],
            airport_event_ids=airport["event_ids"], weather_event_ids=weather["event_ids"],
        ))
        self.assertEqual(result["risk_score"], 16)
        self.assertIn("correlated airport and weather evidence", " ".join(result["mitigations"]))


class BoardabilityTests(unittest.TestCase):
    def test_rejects_flight_inside_boarding_cutoff_even_if_status_is_scheduled(self):
        result = flight_risk.assess_boardability(
            current_time="2026-07-11T16:50:53Z",
            departure_time="2026-07-11T16:59:00Z",
            status="Scheduled",
        )
        self.assertFalse(result["boardable"])
        self.assertEqual(result["reason_code"], "boarding_cutoff_passed")

    def test_rejects_gate_departed_flight(self):
        result = flight_risk.assess_boardability(
            current_time="2026-07-11T16:50:53Z",
            departure_time="2026-07-11T16:59:00Z",
            status="Taxiing / Left Gate",
            actual_out="2026-07-11T16:51:00Z",
        )
        self.assertFalse(result["boardable"])
        self.assertEqual(result["reason_code"], "left_gate")

    def test_rejects_fragile_sub_thirty_minute_option_without_proof(self):
        result = flight_risk.assess_boardability(
            current_time="2026-07-11T16:30:00Z",
            departure_time="2026-07-11T16:55:00Z",
            status="Scheduled",
        )
        self.assertFalse(result["boardable"])
        self.assertEqual(result["reason_code"], "insufficient_lead_time")

    def test_accepts_candidate_with_safe_lead_time(self):
        result = flight_risk.assess_boardability(
            current_time="2026-07-11T16:30:00Z",
            departure_time="2026-07-11T17:30:00Z",
            status="Scheduled",
        )
        self.assertTrue(result["boardable"])
        self.assertEqual(result["reason_code"], "boardable")


class DelayReasonTests(unittest.TestCase):
    def test_confirms_rotation_change_when_current_inbound_was_never_schedule_feasible(self):
        result = flight_risk.infer_rotation_delay_reason(
            passenger_scheduled_departure="2026-07-11T15:55:00Z",
            passenger_estimated_departure="2026-07-11T16:35:00Z",
            inbound_scheduled_arrival="2026-07-11T16:11:00Z",
            inbound_estimated_arrival="2026-07-11T15:52:00Z",
            same_aircraft_confirmed=True,
        )
        self.assertEqual(result["reason_code"], "likely_aircraft_rotation_change")
        self.assertFalse(result["confirmed"])
        self.assertEqual(result["confidence"], "likely")
        self.assertEqual(result["scheduled_overlap_minutes"], 16)
        self.assertEqual(result["estimated_turn_minutes"], 43)
        self.assertIn("likely due to an aircraft rotation change", result["passenger_reason"].lower())

    def test_flags_impossible_original_turn_even_without_literal_schedule_overlap(self):
        result = flight_risk.infer_rotation_delay_reason(
            passenger_scheduled_departure="2026-07-11T18:05:00Z",
            passenger_estimated_departure="2026-07-11T18:52:00Z",
            inbound_scheduled_arrival="2026-07-11T18:03:00Z",
            inbound_estimated_arrival="2026-07-11T18:13:00Z",
            same_aircraft_confirmed=True,
        )
        self.assertEqual(result["reason_code"], "likely_aircraft_rotation_change")
        self.assertEqual(result["scheduled_turn_minutes"], 2)
        self.assertEqual(result["confidence"], "likely")

    def test_distinguishes_late_inbound_from_rotation_change(self):
        result = flight_risk.infer_rotation_delay_reason(
            passenger_scheduled_departure="2026-07-11T15:55:00Z",
            passenger_estimated_departure="2026-07-11T16:35:00Z",
            inbound_scheduled_arrival="2026-07-11T14:55:00Z",
            inbound_estimated_arrival="2026-07-11T15:52:00Z",
            same_aircraft_confirmed=True,
        )
        self.assertEqual(result["reason_code"], "likely_late_inbound_aircraft")
        self.assertFalse(result["confirmed"])
        self.assertEqual(result["confidence"], "likely")

    def test_requires_confirmed_physical_aircraft_link(self):
        result = flight_risk.infer_rotation_delay_reason(
            passenger_scheduled_departure="2026-07-11T15:55:00Z",
            passenger_estimated_departure="2026-07-11T16:35:00Z",
            inbound_scheduled_arrival="2026-07-11T16:11:00Z",
            inbound_estimated_arrival="2026-07-11T15:52:00Z",
            same_aircraft_confirmed=False,
        )
        self.assertEqual(result["reason_code"], "unconfirmed")
        self.assertFalse(result["confirmed"])


class DatabaseTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.db_path = Path(self.tmp.name) / "risk.sqlite"
        self.conn = flight_risk.connect(self.db_path)

    def tearDown(self):
        self.conn.close()
        self.tmp.cleanup()

    def record(self, flight_id, assessed="2026-01-01T10:00:00+00:00", scheduled="2026-01-01T12:00:00+00:00"):
        inputs = healthy()
        result = flight_risk.score_flight(inputs)
        return flight_risk.record_prediction(
            self.conn, flight_id, assessed, inputs, result,
            scheduled_departure=scheduled, marketing_ident="AA1", operating_ident="AAL1",
            origin="KAAA", destination="KBBB", service_date="2026-01-01",
        )

    def test_incomplete_assessment_cannot_be_recorded(self):
        with self.assertRaises(ValueError):
            flight_risk.record_prediction(self.conn, "X", "2026-01-01T00:00:00+00:00", {}, flight_risk.score_flight({}))

    def test_duplicate_snapshots_count_as_one_calibration_flight(self):
        for minute in range(100):
            self.record("SAME", assessed=f"2026-01-01T10:{minute % 60:02d}:00+00:00")
        resolved = flight_risk.resolve_flight(
            self.conn, "SAME", final_status="arrived", arrival_delay_minutes=5,
            resolved_at="2026-01-01T14:00:00+00:00",
        )
        self.assertEqual(resolved["prediction_snapshots"], 100)
        report = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, horizon="1h_to_3h")
        self.assertEqual(report["prediction_snapshots"], 100)
        self.assertEqual(report["unique_resolved_flights"], 1)
        self.assertEqual(report["horizons"]["1h_to_3h"]["canonical_predictions"], 1)

    def test_model_versions_do_not_combine(self):
        self.record("V2")
        flight_risk.resolve_flight(self.conn, "V2", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00+00:00")
        self.record("LEGACY")
        self.conn.execute("UPDATE predictions SET model_version=? WHERE flight_id='LEGACY'", (flight_risk.LEGACY_MODEL_VERSION,))
        self.conn.commit()
        flight_risk.resolve_flight(self.conn, "LEGACY", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00+00:00")
        v2 = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, horizon="1h_to_3h")
        legacy = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, model_version=flight_risk.LEGACY_MODEL_VERSION, horizon="1h_to_3h")
        self.assertEqual(v2["unique_resolved_flights"], 1)
        self.assertEqual(legacy["unique_resolved_flights"], 1)

    def test_outcomes_support_cancellation_and_idempotency(self):
        self.record("CANCEL")
        first = flight_risk.resolve_flight(self.conn, "CANCEL", final_status="cancelled", resolved_at="2026-01-01T14:00:00+00:00")
        again = flight_risk.resolve_flight(self.conn, "CANCEL", final_status="cancelled", resolved_at="2026-01-01T14:00:00+00:00")
        conflict = flight_risk.resolve_flight(self.conn, "CANCEL", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00+00:00")
        corrected = flight_risk.resolve_flight(self.conn, "CANCEL", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00+00:00", correct=True)
        self.assertEqual(first["status"], "resolved")
        self.assertEqual(again["status"], "already_resolved")
        self.assertEqual(conflict["status"], "conflicting_outcome")
        self.assertEqual(corrected["status"], "corrected")
        self.assertEqual(self.conn.execute("SELECT COUNT(*) FROM outcome_audit").fetchone()[0], 1)

    def test_unknown_flight_resolution_is_explicit(self):
        result = flight_risk.resolve_flight(self.conn, "MISSING", final_status="cancelled", resolved_at="2026-01-01T14:00:00+00:00")
        self.assertEqual(result["status"], "unknown_flight")

    def test_rescue_outcome_records_value(self):
        self.record("TRIP")
        outcome_id = flight_risk.record_rescue_outcome(
            self.conn, "TRIP", recommendation="switch", traveler_action="rebooked",
            recorded_at="2026-01-01T12:00:00+00:00", replacement_flight_id="ALT",
            minutes_saved=135, incremental_cost=25, currency="USD",
        )
        row = self.conn.execute("SELECT * FROM rescue_outcomes WHERE id=?", (outcome_id,)).fetchone()
        self.assertEqual(row["minutes_saved"], 135)
        self.assertEqual(row["currency"], "USD")

    def test_major_disruption_calibration_includes_cancellations(self):
        self.record("C1")
        flight_risk.resolve_flight(self.conn, "C1", final_status="cancelled", resolved_at="2026-01-01T14:00:00+00:00")
        report = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, horizon="1h_to_3h")
        bucket = report["horizons"]["1h_to_3h"]["bins"][0]
        self.assertTrue(bucket["major_disruption_sample_ready"])
        self.assertFalse(bucket["major_disruption_publishable"])
        self.assertEqual(bucket["observed_major_disruption_rate"], 1.0)
        self.assertFalse(bucket["on_time_publishable"])

    def test_unknown_outcomes_are_censored_from_calibration(self):
        self.record("UNKNOWN")
        flight_risk.resolve_flight(
            self.conn, "UNKNOWN", final_status="unknown",
            resolved_at="2026-01-01T14:00:00+00:00",
        )
        report = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, horizon="1h_to_3h")
        self.assertEqual(report["unique_resolved_flights"], 0)
        bucket = report["horizons"]["1h_to_3h"]["bins"][0]
        self.assertEqual(bucket["unique_flights"], 0)
        self.assertFalse(bucket["major_disruption_publishable"])

    def test_signed_early_arrival_is_supported(self):
        self.record("EARLY")
        result = flight_risk.resolve_flight(
            self.conn, "EARLY", final_status="arrived",
            departure_delay_minutes=-3, arrival_delay_minutes=-12,
            resolved_at="2026-01-01T14:00:00+00:00",
        )
        self.assertEqual(result["status"], "resolved")
        row = self.conn.execute("SELECT * FROM flight_outcomes WHERE flight_id='EARLY'").fetchone()
        self.assertEqual(row["arrival_delay_minutes"], -12)
        self.assertEqual(row["arrived_within_15"], 1)

    def test_post_departure_snapshot_is_separate_and_not_publishable(self):
        self.record("POST", assessed="2026-01-01T13:00:00+00:00", scheduled="2026-01-01T12:00:00+00:00")
        row = self.conn.execute("SELECT * FROM predictions WHERE flight_id='POST'").fetchone()
        self.assertEqual(row["horizon_bucket"], "post_departure")
        flight_risk.resolve_flight(self.conn, "POST", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00+00:00")
        report = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, horizon="post_departure")
        self.assertFalse(report["probabilities_enabled"])
        self.assertFalse(report["horizons"]["post_departure"]["bins"][0]["on_time_publishable"])

    def test_timestamp_storage_and_canonical_order_are_utc_normalized(self):
        self.record("TZ", assessed="2026-01-01T11:30:00+02:00")  # 09:30Z
        self.record("TZ", assessed="2026-01-01T10:00:00+00:00")  # later
        rows = self.conn.execute("SELECT assessed_at FROM predictions WHERE flight_id='TZ' ORDER BY id").fetchall()
        self.assertEqual(rows[0]["assessed_at"], "2026-01-01T09:30:00+00:00")
        flight_risk.resolve_flight(self.conn, "TZ", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00+00:00")
        canonical = flight_risk._canonical_rows(self.conn, flight_risk.CURRENT_MODEL_VERSION, "1h_to_3h")
        selected = next(row for row in canonical if row["flight_id"] == "TZ")
        self.assertEqual(selected["assessed_at"], "2026-01-01T10:00:00+00:00")

    def test_reused_flight_id_with_conflicting_metadata_is_rejected(self):
        self.record("IDENTITY")
        inputs = healthy()
        result = flight_risk.score_flight(inputs)
        with self.assertRaises(ValueError):
            flight_risk.record_prediction(
                self.conn, "IDENTITY", "2026-01-01T10:30:00+00:00", inputs, result,
                scheduled_departure="2026-01-01T12:00:00+00:00", marketing_ident="AA1",
                operating_ident="AAL1", origin="KCCC", destination="KBBB", service_date="2026-01-01",
            )
        with self.assertRaises(ValueError):
            flight_risk.record_prediction(self.conn, "   ", "2026-01-01T10:00:00Z", inputs, result)

    def test_outcome_idempotency_ignores_later_observation_time(self):
        self.record("IDEMP")
        first = flight_risk.resolve_flight(self.conn, "IDEMP", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00Z")
        again = flight_risk.resolve_flight(self.conn, "IDEMP", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:05:00Z")
        self.assertEqual(first["status"], "resolved")
        self.assertEqual(again["status"], "already_resolved")

    def test_rescue_outcome_rejects_orphans_duplicates_and_bad_math(self):
        with self.assertRaises(ValueError):
            flight_risk.record_rescue_outcome(
                self.conn, "MISSING", recommendation="switch", traveler_action="rebooked",
                recorded_at="2026-01-01T12:00:00Z", idempotency_key="evt-1",
            )
        self.record("TRIP2")
        kwargs = dict(
            recommendation="switch", traveler_action="rebooked", recorded_at="2026-01-01T12:00:00Z",
            original_expected_arrival="2026-01-01T15:00:00Z", actual_traveler_arrival="2026-01-01T14:00:00Z",
            minutes_saved=60, idempotency_key="evt-2",
        )
        first = flight_risk.record_rescue_outcome(self.conn, "TRIP2", **kwargs)
        second = flight_risk.record_rescue_outcome(self.conn, "TRIP2", **kwargs)
        self.assertEqual(first, second)
        with self.assertRaises(ValueError):
            flight_risk.record_rescue_outcome(self.conn, "TRIP2", **{**kwargs, "idempotency_key": "evt-3", "minutes_saved": 90})

    def test_raw_probability_is_null_and_validation_gate_stays_closed(self):
        self.record("NULLPROB")
        self.assertIsNone(self.conn.execute("SELECT raw_probability FROM predictions WHERE flight_id='NULLPROB'").fetchone()[0])
        flight_risk.resolve_flight(self.conn, "NULLPROB", final_status="arrived", arrival_delay_minutes=5, resolved_at="2026-01-01T14:00:00Z")
        report = flight_risk.report_calibration(self.conn, min_total=1, min_bin=1, horizon="1h_to_3h")
        self.assertFalse(report["probabilities_enabled"])
        self.assertEqual(report["publication_blocker"], "out_of_sample_validation_required")

    def test_invalid_calibration_thresholds_are_rejected(self):
        with self.assertRaises(ValueError):
            flight_risk.report_calibration(self.conn, min_total=0, min_bin=20)
        with self.assertRaises(ValueError):
            flight_risk.report_calibration(self.conn, min_total=100, min_bin=-1)

    def test_schema_migrates_legacy_database(self):
        self.conn.close()
        legacy_path = Path(self.tmp.name) / "legacy.sqlite"
        raw = sqlite3.connect(legacy_path)
        raw.execute("""CREATE TABLE predictions (
            id INTEGER PRIMARY KEY AUTOINCREMENT, flight_id TEXT NOT NULL, assessed_at TEXT NOT NULL,
            risk_score INTEGER NOT NULL, risk_label TEXT NOT NULL, raw_probability REAL NOT NULL,
            inputs_json TEXT NOT NULL, factors_json TEXT NOT NULL, resolved_at TEXT,
            outcome_delay_minutes REAL, on_time INTEGER)""")
        raw.commit(); raw.close()
        migrated = flight_risk.connect(legacy_path)
        columns = {row[1] for row in migrated.execute("PRAGMA table_info(predictions)")}
        self.assertIn("model_version", columns)
        self.assertIn("horizon_bucket", columns)
        self.assertEqual(migrated.execute("SELECT value FROM schema_metadata WHERE key='schema_version'").fetchone()[0], str(flight_risk.SCHEMA_VERSION))
        migrated.close()
        self.conn = flight_risk.connect(self.db_path)


class CliTests(unittest.TestCase):
    def test_incomplete_cli_invocation_fails(self):
        result = subprocess.run(
            [sys.executable, str(MODULE_PATH), "assess", "--flight-id", "X"],
            text=True, capture_output=True,
        )
        self.assertNotEqual(result.returncode, 0)
        self.assertIn("required", result.stderr)

    def test_complete_cli_assessment(self):
        with tempfile.TemporaryDirectory() as tmp:
            result = subprocess.run([
                sys.executable, str(MODULE_PATH), "--db", str(Path(tmp) / "x.sqlite"), "assess",
                "--flight-id", "PHYSICAL-1",
                "--passenger-flight-delay-minutes", "0",
                "--upstream-rotation-delay-minutes", "0",
                "--upstream-legs", "0",
                "--airport-severity", "0", "--weather-severity", "0",
                "--tail-status", "confirmed", "--location-confidence", "actual",
            ], text=True, capture_output=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(json.loads(result.stdout)["risk_label"], "low")


if __name__ == "__main__":
    unittest.main()
