import importlib.util
import pathlib
import sys
import unittest

MODULE_PATH = pathlib.Path(__file__).with_name("turbli_forecast.py")
SPEC = importlib.util.spec_from_file_location("turbli_forecast", MODULE_PATH)
MODULE = importlib.util.module_from_spec(SPEC)
assert SPEC.loader
sys.modules[SPEC.name] = MODULE
SPEC.loader.exec_module(MODULE)


class TurbliForecastTests(unittest.TestCase):
    def test_build_url_normalizes_flight(self):
        self.assertEqual(
            MODULE.build_url("bna", "slc", "2026-07-11", "DL 2205"),
            "https://turbli.com/BNA/SLC/2026-07-11/DL-2205/",
        )

    def test_parses_turbulence_and_thunderstorm_warnings(self):
        page = r'''
        <script>
        var warning_turb = ("Just some light turbulence, smooth flight!").substring(0, 48);
        var warning_cb = ("Medium size thunderstorms on the way. Your pilot will consider an alternative route").substring(0, 84);
        </script>
        '''
        turbulence, storms = MODULE.parse_forecast_page(page)
        self.assertEqual(turbulence, "Just some light turbulence, smooth flight!")
        self.assertEqual(
            storms,
            "Medium size thunderstorms on the way. Your pilot will consider an alternative route",
        )

    def test_zero_warning_is_omitted(self):
        page = 'var warning_turb = ("Light turbulence").substring(0, 16); var warning_cb = ("0").substring(0, 1);'
        self.assertEqual(MODULE.parse_forecast_page(page), ("Light turbulence", None))

    def test_extracts_peak_turbulence_timing(self):
        page = '''
        var time = [1000, 1600, 2200, 2800, 3400, 4000, 4600, 5200, 5800];
        var CAT = [5, 7, 15, 18, 14, 6, 8, 17, 19];
        '''
        windows, timing = MODULE.turbulence_timing(page)
        self.assertEqual(len(windows), 2)
        self.assertEqual(windows[0]["level"], "light")
        self.assertIn("after takeoff", timing)

    def test_smooth_chart_has_no_timing_claim(self):
        page = 'var time = [1000, 1600, 2200]; var CAT = [2, 3, 4];'
        self.assertEqual(MODULE.turbulence_timing(page), ([], None))

    def test_invalid_airport_is_rejected(self):
        with self.assertRaises(ValueError):
            MODULE.build_url("NASHVILLE", "SLC", "2026-07-11", "DL2205")


if __name__ == "__main__":
    unittest.main()
