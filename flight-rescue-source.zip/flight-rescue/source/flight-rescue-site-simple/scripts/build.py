#!/usr/bin/env python3
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'dist'
FILES = ['index.html', 'waitlist.html', 'styles.css', 'faq.html', 'privacy.html', 'terms.html', 'sms-terms.html', 'disclaimer.html', 'legal.css']
if DIST.exists():
    shutil.rmtree(DIST)
DIST.mkdir()
for relative in FILES:
    source = ROOT / relative
    if not source.is_file():
        raise SystemExit(f'Missing required file: {relative}')
    shutil.copy2(source, DIST / relative)
shutil.copytree(ROOT / 'assets', DIST / 'assets')
print(f'Built simplified preview: {len(FILES)} files plus assets')
