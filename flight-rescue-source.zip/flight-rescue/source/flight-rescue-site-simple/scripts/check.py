#!/usr/bin/env python3
from html.parser import HTMLParser
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / 'index.html').read_text()
css = (ROOT / 'styles.css').read_text()
faq = (ROOT / 'faq.html').read_text()
errors = []

class Parser(HTMLParser):
    pass
try:
    Parser().feed(html)
except Exception as exc:
    errors.append(f'HTML parse failed: {exc}')

for marker in [
    'Your flight changed.', 'Know what to do next.', 'Three simple steps.',
    'Advice. Not autopilot.', 'The whole trip, on one screen.',
    'flight-compare', 'trip-board', 'Turbulence forecast',
    '10:05 PM', '8:05 PM',
    'This comparison preview does not collect signups.',
    'aria-disabled="true"', 'name="robots" content="noindex,nofollow,noarchive"',
]:
    if marker not in html:
        errors.append(f'Missing content marker: {marker}')
for forbidden in ['<form', 'data-netlify', 'private_server.py']:
    if forbidden in html:
        errors.append(f'Preview must not expose active collection: {forbidden}')
if '<section class="faq ' in html or 'faq-list' in html:
    errors.append('FAQ content must live on the standalone FAQ page, not the homepage')
if html.count('href="faq.html"') < 2:
    errors.append('Homepage must link to FAQs in both the header and footer')
for marker in ['Frequently asked questions', 'What do I send?', 'What exactly is Flight Rescue?']:
    if marker not in faq:
        errors.append(f'Missing FAQ marker: {marker}')
if css.count('{') != css.count('}'):
    errors.append('Unbalanced CSS braces')
for marker in ['@media(max-width:800px)', '@media(max-width:420px)', '@media(prefers-reduced-motion:reduce)']:
    if marker not in css:
        errors.append(f'Missing responsive marker: {marker}')
for path in ['faq.html','privacy.html','terms.html','sms-terms.html','disclaimer.html','assets/flight-rescue-logo.png','assets/flight-rescue-favicon.png']:
    if not (ROOT / path).is_file():
        errors.append(f'Missing file: {path}')
if errors:
    print('Simplified-site check failed:')
    print('\n'.join(f'- {e}' for e in errors))
    sys.exit(1)
print('Simplified-site check passed: concise copy, disabled CTAs, no collection, legal pages, responsive CSS, and noindex metadata.')
