const navLinks = document.querySelectorAll('a[href^="#"]');
navLinks.forEach(link => link.addEventListener('click', event => {
  const target = document.querySelector(link.getAttribute('href'));
  if (!target) return;
  event.preventDefault();
  target.scrollIntoView({ behavior: 'smooth', block: 'start' });
}));

const card = document.querySelector('.decision-card');
if (card && window.matchMedia('(pointer: fine)').matches) {
  card.addEventListener('mousemove', event => {
    const bounds = card.getBoundingClientRect();
    const x = (event.clientX - bounds.left) / bounds.width - 0.5;
    const y = (event.clientY - bounds.top) / bounds.height - 0.5;
    card.style.transform = `perspective(900px) rotateY(${x * 2.2}deg) rotateX(${-y * 2.2}deg) rotateZ(-.5deg)`;
  });
  card.addEventListener('mouseleave', () => {
    card.style.transform = 'rotate(-.5deg)';
  });
}
