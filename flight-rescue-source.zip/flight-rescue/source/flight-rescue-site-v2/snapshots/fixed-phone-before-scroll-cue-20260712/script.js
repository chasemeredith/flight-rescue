const tabs = document.querySelectorAll('.scenario-tab');
const threads = document.querySelectorAll('.scenario');

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const scenario = tab.dataset.scenario;
    tabs.forEach(item => {
      const active = item === tab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    threads.forEach(thread => {
      const active = thread.dataset.thread === scenario;
      thread.hidden = !active;
      thread.classList.toggle('active', active);
      if (active) thread.scrollTop = 0;
    });
  });
});
