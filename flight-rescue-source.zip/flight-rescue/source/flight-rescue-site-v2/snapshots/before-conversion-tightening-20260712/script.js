const tabs = document.querySelectorAll('.scenario-tab');
const threads = document.querySelectorAll('.scenario');
const phone = document.querySelector('.phone');
const scrollCue = document.createElement('div');

scrollCue.className = 'scroll-cue';
scrollCue.setAttribute('aria-hidden', 'true');
scrollCue.innerHTML = '<span>Scroll conversation <b>↓</b></span>';
phone.appendChild(scrollCue);

const updateScrollCue = thread => {
  const canScroll = thread.scrollHeight > thread.clientHeight + 1;
  const dismissed = thread.dataset.scrollCueSeen === 'true';
  scrollCue.classList.toggle('is-hidden', thread.hidden || !canScroll || dismissed);
};

threads.forEach(thread => {
  thread.addEventListener('scroll', () => {
    if (thread.scrollTop > 8) thread.dataset.scrollCueSeen = 'true';
    if (!thread.hidden) updateScrollCue(thread);
  }, { passive: true });
});

requestAnimationFrame(() => updateScrollCue(document.querySelector('.scenario:not([hidden])')));

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const scenario = tab.dataset.scenario;
    tabs.forEach(item => {
      const active = item === tab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    threads.forEach(thread => {
      const active = thread.dataset.thread === scenario;
      thread.hidden = !active;
      thread.classList.toggle('active', active);
      if (active) {
        thread.scrollTop = 0;
        requestAnimationFrame(() => updateScrollCue(thread));
      }
    });
  });
});
