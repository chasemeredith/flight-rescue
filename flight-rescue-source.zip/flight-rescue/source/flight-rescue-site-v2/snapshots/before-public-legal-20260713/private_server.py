#!/usr/bin/env python3
import base64
import csv
import hmac
import json
import os
import re
import threading
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path

USER = os.environ.get("SITE_USER", "preview")
PASSWORD = os.environ["SITE_PASSWORD"]
EXPECTED = "Basic " + base64.b64encode(f"{USER}:{PASSWORD}".encode()).decode()
DATA_PATH = Path(os.environ.get("WAITLIST_PATH", "~/.local/share/flight-rescue/waitlist.csv")).expanduser()
CONSENT_VERSION = "launch-beta-sms-v1"
WRITE_LOCK = threading.Lock()
NAME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ' .-]{1,50}$")


def normalize_phone(value):
    digits = re.sub(r"\D", "", str(value or ""))
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) != 10 or digits[0] in "01" or digits[3] in "01":
        return None
    return "+1" + digits


def clean_name(value):
    value = " ".join(str(value or "").strip().split())
    return value if NAME_RE.fullmatch(value) else None


def save_signup(first_name, last_name, phone, source):
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    with WRITE_LOCK:
        rows = []
        if DATA_PATH.exists():
            with DATA_PATH.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
        if any(row.get("phone") == phone for row in rows):
            return False
        rows.append({
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "first_name": first_name,
            "last_name": last_name,
            "phone": phone,
            "consent_version": CONSENT_VERSION,
            "source": source,
        })
        temp_path = DATA_PATH.with_suffix(".tmp")
        fields = ["created_at_utc", "first_name", "last_name", "phone", "consent_version", "source"]
        with temp_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
        os.chmod(temp_path, 0o600)
        os.replace(temp_path, DATA_PATH)
        os.chmod(DATA_PATH, 0o600)
        return True


class Handler(SimpleHTTPRequestHandler):
    def authenticated(self):
        return hmac.compare_digest(self.headers.get("Authorization", ""), EXPECTED)

    def require_auth(self):
        if self.authenticated():
            return True
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Flight Rescue design v2"')
        self.end_headers()
        self.wfile.write(b"Private preview")
        return False

    def send_json(self, status, payload):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.require_auth():
            return
        super().do_GET()

    def do_HEAD(self):
        if not self.require_auth():
            return
        super().do_HEAD()

    def do_POST(self):
        if not self.require_auth():
            return
        if self.path != "/api/waitlist":
            self.send_json(404, {"error": "Not found."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > 8192 or "application/json" not in self.headers.get("Content-Type", ""):
            self.send_json(400, {"error": "Invalid request."})
            return
        try:
            payload = json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_json(400, {"error": "Invalid request."})
            return
        if payload.get("website"):
            self.send_json(201, {"ok": True})
            return
        first_name = clean_name(payload.get("first_name"))
        last_name = clean_name(payload.get("last_name"))
        phone = normalize_phone(payload.get("phone"))
        if not first_name or not last_name:
            self.send_json(422, {"error": "Enter your first and last name."})
            return
        if not phone:
            self.send_json(422, {"error": "Enter a valid U.S. mobile number."})
            return
        if payload.get("consent") is not True:
            self.send_json(422, {"error": "Consent is required to send the launch text."})
            return
        source = re.sub(r"[^A-Za-z0-9_.-]", "", str(payload.get("source", "site")))[:40] or "site"
        created = save_signup(first_name, last_name, phone, source)
        self.send_json(201 if created else 200, {"ok": True, "duplicate": not created})

    def end_headers(self):
        self.send_header("X-Robots-Tag", "noindex, nofollow, noarchive")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("Referrer-Policy", "same-origin")
        super().end_headers()


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    ThreadingHTTPServer(("127.0.0.1", 4175), Handler).serve_forever()
