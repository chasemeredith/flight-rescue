const form = document.querySelector('#waitlist-form');
const submit = document.querySelector('#waitlist-submit');
const status = document.querySelector('#form-status');
const success = document.querySelector('#waitlist-success');

const setError = message => {
  status.textContent = message;
  status.focus?.();
};

form.addEventListener('submit', async event => {
  event.preventDefault();
  setError('');

  if (!form.reportValidity()) return;

  submit.disabled = true;
  submit.firstChild.textContent = 'Joining… ';

  const data = Object.fromEntries(new FormData(form));
  data.consent = document.querySelector('#consent').checked;
  data.source = 'flight-rescue-site';

  try {
    const response = await fetch('/api/waitlist', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'We could not add you right now. Please try again.');

    form.hidden = true;
    success.hidden = false;
    success.querySelector('h2').focus?.();
  } catch (error) {
    setError(error.message || 'We could not add you right now. Please try again.');
    submit.disabled = false;
    submit.firstChild.textContent = 'Join the waitlist ';
  }
});
