const form = document.querySelector('#waitlist-form');
const submit = document.querySelector('#waitlist-submit');
const status = document.querySelector('#form-status');
const success = document.querySelector('#waitlist-success');
const analyticsParams = new URLSearchParams(window.location.search);
const analyticsVisitId = crypto.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;
let formStarted = false;

const trackConversion = (event, label = '') => {
  fetch('/api/events', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify({
      event,
      label,
      path: window.location.pathname,
      referrer: document.referrer,
      utm_source: analyticsParams.get('utm_source') || '',
      utm_medium: analyticsParams.get('utm_medium') || '',
      utm_campaign: analyticsParams.get('utm_campaign') || '',
      visit_id: analyticsVisitId
    }),
    keepalive: true
  }).catch(() => {});
};

trackConversion('page_view', 'waitlist');
form.addEventListener('input', () => {
  if (formStarted) return;
  formStarted = true;
  trackConversion('waitlist_form_start', analyticsParams.get('source') || 'direct');
});

const setError = message => {
  status.textContent = message;
  status.focus?.();
};

form.addEventListener('submit', async event => {
  event.preventDefault();
  setError('');

  if (!form.reportValidity()) return;

  submit.disabled = true;
  submit.firstChild.textContent = 'Joining… ';

  const data = Object.fromEntries(new FormData(form));
  data.consent = document.querySelector('#consent').checked;
  const signupSource = (analyticsParams.get('source') || 'direct').replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 24);
  data.source = `flight-rescue-site-${signupSource || 'direct'}`;

  try {
    const response = await fetch('/api/waitlist', {
      method: 'POST',
      headers: {'Content-Type': 'application/json'},
      body: JSON.stringify(data)
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'We could not add you right now. Please try again.');

    form.hidden = true;
    success.hidden = false;
    trackConversion('waitlist_signup_success', signupSource || 'direct');
    success.querySelector('h2').focus?.();
  } catch (error) {
    setError(error.message || 'We could not add you right now. Please try again.');
    submit.disabled = false;
    submit.firstChild.textContent = 'Join the waitlist ';
  }
});
