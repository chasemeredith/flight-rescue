const tabs = document.querySelectorAll('.scenario-tab');
const threads = document.querySelectorAll('.scenario');
const phone = document.querySelector('.phone');
const scenarioTabs = document.querySelector('.scenario-tabs');
const conversation = document.querySelector('.conversation');
const processPanel = document.querySelector('.process');
const scenarioTabsAnchor = document.createComment('scenario-tabs-desktop-position');
const scrollCue = document.createElement('div');
const analyticsParams = new URLSearchParams(window.location.search);
const analyticsVisitId = crypto.randomUUID?.() || `${Date.now()}-${Math.random().toString(16).slice(2)}`;

const trackConversion = (event, label = '') => {
  const payload = {
    event,
    label,
    path: window.location.pathname,
    referrer: document.referrer,
    utm_source: analyticsParams.get('utm_source') || '',
    utm_medium: analyticsParams.get('utm_medium') || '',
    utm_campaign: analyticsParams.get('utm_campaign') || '',
    visit_id: analyticsVisitId
  };
  fetch('/api/events', {
    method: 'POST',
    headers: {'Content-Type': 'application/json'},
    body: JSON.stringify(payload),
    keepalive: true
  }).catch(() => {});
};

trackConversion('page_view', 'landing');
document.querySelectorAll('[data-analytics-label]').forEach(link => {
  link.addEventListener('click', () => trackConversion('waitlist_cta_click', link.dataset.analyticsLabel));
});

scrollCue.className = 'scroll-cue';
scrollCue.setAttribute('aria-hidden', 'true');
scrollCue.innerHTML = '<span>Scroll conversation <b>↓</b></span>';
phone.appendChild(scrollCue);

scenarioTabs.before(scenarioTabsAnchor);
const portraitMobile = window.matchMedia('(max-width: 780px) and (orientation: portrait)');
const placeScenarioTabs = () => {
  if (portraitMobile.matches) {
    conversation.insertBefore(scenarioTabs, processPanel);
  } else {
    scenarioTabsAnchor.parentNode.insertBefore(scenarioTabs, scenarioTabsAnchor.nextSibling);
  }
};
placeScenarioTabs();
portraitMobile.addEventListener?.('change', placeScenarioTabs);

const updateScrollCue = thread => {
  const canScroll = thread.scrollHeight > thread.clientHeight + 1;
  const dismissed = thread.dataset.scrollCueSeen === 'true';
  scrollCue.classList.toggle('is-hidden', thread.hidden || !canScroll || dismissed);
};

threads.forEach(thread => {
  thread.addEventListener('scroll', () => {
    if (thread.scrollTop > 8) thread.dataset.scrollCueSeen = 'true';
    if (!thread.hidden) updateScrollCue(thread);
  }, { passive: true });
});

requestAnimationFrame(() => updateScrollCue(document.querySelector('.scenario:not([hidden])')));

tabs.forEach(tab => {
  tab.addEventListener('click', () => {
    const scenario = tab.dataset.scenario;
    tabs.forEach(item => {
      const active = item === tab;
      item.classList.toggle('active', active);
      item.setAttribute('aria-selected', String(active));
    });
    threads.forEach(thread => {
      const active = thread.dataset.thread === scenario;
      thread.hidden = !active;
      thread.classList.toggle('active', active);
      if (active) {
        thread.scrollTop = 0;
        requestAnimationFrame(() => updateScrollCue(thread));
      }
    });
  });
});
