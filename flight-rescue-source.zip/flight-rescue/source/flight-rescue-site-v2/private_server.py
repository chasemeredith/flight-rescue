#!/usr/bin/env python3
import base64
import csv
import hmac
import json
import os
import re
import threading
import time
from collections import defaultdict, deque
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
from urllib.parse import unquote, urlsplit


def env_true(name, default=False):
    value = os.environ.get(name)
    if value is None:
        return default
    return value.strip().lower() in {"1", "true", "yes", "on"}


SITE_PUBLIC = env_true("SITE_PUBLIC")
USER = os.environ.get("SITE_USER", "preview")
PASSWORD = os.environ.get("SITE_PASSWORD", "")
if not SITE_PUBLIC and not PASSWORD:
    raise RuntimeError("SITE_PASSWORD is required unless SITE_PUBLIC=true")
EXPECTED = "Basic " + base64.b64encode(f"{USER}:{PASSWORD}".encode()).decode() if PASSWORD else ""
DATA_PATH = Path(os.environ.get("WAITLIST_PATH", "~/.local/share/flight-rescue/waitlist.csv")).expanduser()
ANALYTICS_PATH = Path(os.environ.get("ANALYTICS_PATH", "~/.local/share/flight-rescue/analytics-events.csv")).expanduser()
CONSENT_VERSION = "launch-beta-sms-v3"
WRITE_LOCK = threading.Lock()
ANALYTICS_LOCK = threading.Lock()
RATE_LOCK = threading.Lock()
RATE_LIMIT_WINDOW_SECONDS = int(os.environ.get("WAITLIST_RATE_WINDOW", "600"))
RATE_LIMIT_MAX = int(os.environ.get("WAITLIST_RATE_MAX", "5"))
RATE_BUCKETS = defaultdict(deque)
ANALYTICS_RATE_MAX = int(os.environ.get("ANALYTICS_RATE_MAX", "120"))
ANALYTICS_RATE_BUCKETS = defaultdict(deque)
NAME_RE = re.compile(r"^[A-Za-zÀ-ÖØ-öø-ÿ' .-]{1,50}$")
EMAIL_RE = re.compile(r"^[^@\s]+@[^@\s]+\.[^@\s]+$")
EVENT_NAMES = {"page_view", "waitlist_cta_click", "waitlist_form_start", "waitlist_signup_success"}
PUBLIC_FILES = {
    "/", "/index.html", "/waitlist.html", "/privacy.html", "/terms.html",
    "/sms-terms.html", "/disclaimer.html", "/styles.css", "/waitlist.css",
    "/legal.css", "/script.js", "/waitlist.js", "/robots.txt",
    "/.well-known/security.txt",
}
PUBLIC_ASSET_SUFFIXES = {".png", ".jpg", ".jpeg", ".webp", ".svg", ".ico", ".woff2"}


def normalize_phone(value):
    digits = re.sub(r"\D", "", str(value or ""))
    if len(digits) == 11 and digits.startswith("1"):
        digits = digits[1:]
    if len(digits) != 10 or digits[0] in "01" or digits[3] in "01":
        return None
    return "+1" + digits


def clean_name(value):
    value = " ".join(str(value or "").strip().split())
    return value if NAME_RE.fullmatch(value) else None


def clean_email(value):
    value = str(value or "").strip().lower()
    if not value:
        return ""
    return value if len(value) <= 254 and EMAIL_RE.fullmatch(value) else None


def save_signup(first_name, last_name, phone, email, source):
    DATA_PATH.parent.mkdir(parents=True, exist_ok=True)
    with WRITE_LOCK:
        rows = []
        if DATA_PATH.exists():
            with DATA_PATH.open(newline="", encoding="utf-8") as handle:
                rows = list(csv.DictReader(handle))
        if any(row.get("phone") == phone for row in rows):
            return False
        rows.append({
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "first_name": first_name,
            "last_name": last_name,
            "phone": phone,
            "email": email,
            "consent_version": CONSENT_VERSION,
            "source": source,
        })
        temp_path = DATA_PATH.with_suffix(".tmp")
        fields = ["created_at_utc", "first_name", "last_name", "phone", "email", "consent_version", "source"]
        with temp_path.open("w", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            writer.writeheader()
            writer.writerows(rows)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(temp_path, 0o600)
        os.replace(temp_path, DATA_PATH)
        os.chmod(DATA_PATH, 0o600)
        return True


def clean_event_text(value, limit=160):
    return re.sub(r"[\r\n\t]+", " ", str(value or "")).strip()[:limit]


def save_event(event, payload):
    ANALYTICS_PATH.parent.mkdir(parents=True, exist_ok=True)
    fields = ["created_at_utc", "event", "path", "label", "referrer", "utm_source", "utm_medium", "utm_campaign", "visit_id"]
    row = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "event": event,
        "path": clean_event_text(payload.get("path"), 120),
        "label": clean_event_text(payload.get("label"), 60),
        "referrer": clean_event_text(payload.get("referrer"), 240),
        "utm_source": clean_event_text(payload.get("utm_source"), 80),
        "utm_medium": clean_event_text(payload.get("utm_medium"), 80),
        "utm_campaign": clean_event_text(payload.get("utm_campaign"), 80),
        "visit_id": clean_event_text(payload.get("visit_id"), 64),
    }
    with ANALYTICS_LOCK:
        new_file = not ANALYTICS_PATH.exists() or ANALYTICS_PATH.stat().st_size == 0
        descriptor = os.open(ANALYTICS_PATH, os.O_WRONLY | os.O_CREAT | os.O_APPEND, 0o600)
        with os.fdopen(descriptor, "a", newline="", encoding="utf-8") as handle:
            writer = csv.DictWriter(handle, fieldnames=fields)
            if new_file:
                writer.writeheader()
            writer.writerow(row)
            handle.flush()
            os.fsync(handle.fileno())
        os.chmod(ANALYTICS_PATH, 0o600)


def rate_limited(client_key):
    now = time.monotonic()
    cutoff = now - RATE_LIMIT_WINDOW_SECONDS
    with RATE_LOCK:
        bucket = RATE_BUCKETS[client_key]
        while bucket and bucket[0] <= cutoff:
            bucket.popleft()
        if len(bucket) >= RATE_LIMIT_MAX:
            return True
        bucket.append(now)
        return False


def analytics_rate_limited(client_key):
    now = time.monotonic()
    cutoff = now - RATE_LIMIT_WINDOW_SECONDS
    with RATE_LOCK:
        bucket = ANALYTICS_RATE_BUCKETS[client_key]
        while bucket and bucket[0] <= cutoff:
            bucket.popleft()
        if len(bucket) >= ANALYTICS_RATE_MAX:
            return True
        bucket.append(now)
        return False


class Handler(SimpleHTTPRequestHandler):
    server_version = "FlightRescueWaitlist/1.0"

    def authenticated(self):
        if SITE_PUBLIC:
            return True
        return hmac.compare_digest(self.headers.get("Authorization", ""), EXPECTED)

    def require_auth(self):
        if self.authenticated():
            return True
        self.send_response(401)
        self.send_header("WWW-Authenticate", 'Basic realm="Flight Rescue private preview"')
        self.end_headers()
        self.wfile.write(b"Private preview")
        return False

    def client_key(self):
        forwarded = self.headers.get("CF-Connecting-IP") or self.headers.get("X-Forwarded-For", "")
        return forwarded.split(",", 1)[0].strip() or self.client_address[0]

    def public_path_allowed(self):
        path = unquote(urlsplit(self.path).path)
        if path in PUBLIC_FILES:
            return True
        if not path.startswith("/assets/"):
            return False
        root = (Path.cwd() / "assets").resolve()
        target = (Path.cwd() / path.lstrip("/")).resolve()
        try:
            target.relative_to(root)
        except ValueError:
            return False
        return target.is_file() and target.suffix.lower() in PUBLIC_ASSET_SUFFIXES

    def require_public_path(self):
        if not SITE_PUBLIC or self.public_path_allowed():
            return True
        self.send_error(404, "Not found")
        return False

    def send_json(self, status, payload, extra_headers=None):
        body = json.dumps(payload).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        for name, value in (extra_headers or {}).items():
            self.send_header(name, value)
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self.require_auth():
            return
        if not self.require_public_path():
            return
        super().do_GET()

    def do_HEAD(self):
        if not self.require_auth():
            return
        if not self.require_public_path():
            return
        super().do_HEAD()

    def do_POST(self):
        if not self.require_auth():
            return
        path = urlsplit(self.path).path
        if path not in {"/api/waitlist", "/api/events"}:
            self.send_json(404, {"error": "Not found."})
            return
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            length = 0
        if length <= 0 or length > 8192 or "application/json" not in self.headers.get("Content-Type", ""):
            self.send_json(400, {"error": "Invalid request."})
            return
        try:
            payload = json.loads(self.rfile.read(length))
        except (json.JSONDecodeError, UnicodeDecodeError):
            self.send_json(400, {"error": "Invalid request."})
            return
        if path == "/api/events":
            event = clean_event_text(payload.get("event"), 60)
            if event not in EVENT_NAMES:
                self.send_json(422, {"error": "Invalid event."})
                return
            if analytics_rate_limited(self.client_key()):
                self.send_json(429, {"error": "Too many events."}, {"Retry-After": str(RATE_LIMIT_WINDOW_SECONDS)})
                return
            save_event(event, payload)
            self.send_response(204)
            self.end_headers()
            return
        if payload.get("website"):
            self.send_json(201, {"ok": True})
            return
        if rate_limited(self.client_key()):
            self.send_json(429, {"error": "Too many attempts. Please try again in a few minutes."}, {"Retry-After": str(RATE_LIMIT_WINDOW_SECONDS)})
            return
        first_name = clean_name(payload.get("first_name"))
        raw_last_name = " ".join(str(payload.get("last_name") or "").strip().split())
        last_name = clean_name(raw_last_name) if raw_last_name else ""
        phone = normalize_phone(payload.get("phone"))
        email = clean_email(payload.get("email"))
        if not first_name:
            self.send_json(422, {"error": "Enter your first name."})
            return
        if last_name is None:
            self.send_json(422, {"error": "Enter a valid last name or leave it blank."})
            return
        if not phone:
            self.send_json(422, {"error": "Enter a valid U.S. mobile number."})
            return
        if email is None:
            self.send_json(422, {"error": "Enter a valid email address or leave it blank."})
            return
        if payload.get("consent") is not True:
            self.send_json(422, {"error": "Consent is required to send the launch text."})
            return
        source = re.sub(r"[^A-Za-z0-9_.-]", "", str(payload.get("source", "site")))[:40] or "site"
        created = save_signup(first_name, last_name, phone, email, source)
        self.send_json(201 if created else 200, {"ok": True, "duplicate": not created})

    def end_headers(self):
        if not SITE_PUBLIC:
            self.send_header("X-Robots-Tag", "noindex, nofollow, noarchive")
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "strict-origin-when-cross-origin")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header(
            "Content-Security-Policy",
            "default-src 'self'; script-src 'self'; style-src 'self' https://fonts.googleapis.com; "
            "font-src 'self' https://fonts.gstatic.com; img-src 'self' data:; connect-src 'self'; "
            "base-uri 'self'; form-action 'self'; frame-ancestors 'none'",
        )
        super().end_headers()


if __name__ == "__main__":
    os.chdir(os.path.dirname(os.path.abspath(__file__)))
    host = os.environ.get("SITE_HOST", "127.0.0.1")
    port = int(os.environ.get("SITE_PORT", "4175"))
    ThreadingHTTPServer((host, port), Handler).serve_forever()
