# Public waitlist launch

The site can run in two modes:

- Private preview: omit `SITE_PUBLIC` and set `SITE_PASSWORD`.
- Public waitlist: set `SITE_PUBLIC=true`. Authentication is disabled, public pages are indexable, and the waitlist endpoint remains validation-, honeypot-, duplicate-, and rate-limit-protected.

Required production environment:

```text
SITE_PUBLIC=true
SITE_HOST=127.0.0.1
SITE_PORT=4175
WAITLIST_PATH=/absolute/path/on/persistent-storage/waitlist.csv
ANALYTICS_PATH=/absolute/path/on/persistent-storage/analytics-events.csv
WAITLIST_RATE_MAX=5
WAITLIST_RATE_WINDOW=600
ANALYTICS_RATE_MAX=120
```

Put the server behind a durable HTTPS reverse proxy or managed host. Do not expose the Python server directly to the internet. The waitlist and analytics files must live on persistent, backed-up storage outside the web root. Their permissions are set to `0600` after writes. Analytics records contain conversion events, page paths, CTA labels, referrers, campaign parameters, and an ephemeral page-visit identifier; they do not contain submitted names, phone numbers, email addresses, or stored IP addresses.

Before publishing:

1. Set the final domain and HTTPS.
2. Verify `GET /`, `/waitlist.html`, all four legal pages, `/robots.txt`, and `/.well-known/security.txt` return 200 without authentication.
3. Submit one controlled test signup to a temporary `WAITLIST_PATH`, verify `201`, duplicate `200`, invalid `422`, and rate limit `429`.
4. Confirm the production waitlist is empty before launch.
5. Verify a controlled `POST /api/events` returns `204`, an unknown event returns `422`, and the resulting analytics file contains no signup fields or IP-address column.
6. Confirm `support@getflightrescue.com` is used for legal/support contact and `info@getflightrescue.com` is used for general questions.
7. Verify the canonical URL and Open Graph image use the final production domain before publishing.
8. Register the launch/beta SMS campaign with the messaging provider before sending any waitlist texts. Sending is separate from collection and requires working STOP and HELP handling.

These pages are a practical launch baseline, not a substitute for advice from a qualified attorney.
