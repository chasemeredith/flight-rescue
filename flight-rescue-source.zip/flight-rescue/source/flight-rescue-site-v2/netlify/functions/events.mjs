import { randomUUID, createHash } from 'node:crypto';
import { getStore } from '@netlify/blobs';

const EVENTS = new Set(['page_view', 'waitlist_cta_click', 'waitlist_form_start', 'waitlist_signup_success']);
const WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX = 120;
const clean = (value, limit) => String(value || '').replace(/[\r\n\t]+/g, ' ').trim().slice(0, limit);
const digest = value => createHash('sha256').update(value).digest('hex');

export default async (request) => {
  if (request.method !== 'POST') return new Response(null, {status: 405, headers: {Allow: 'POST'}});
  let payload;
  try {
    const raw = await request.text();
    if (!raw || raw.length > 8192) throw new Error('invalid');
    payload = JSON.parse(raw);
  } catch {
    return Response.json({error: 'Invalid request.'}, {status: 400});
  }
  const event = clean(payload.event, 60);
  if (!EVENTS.has(event)) return Response.json({error: 'Invalid event.'}, {status: 422});

  const ip = request.headers.get('x-nf-client-connection-ip') || request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() || 'unknown';
  const window = Math.floor(Date.now() / WINDOW_MS);
  const rates = getStore('analytics-rate-limits');
  const rateKey = `${window}/${digest(ip)}`;
  const prior = await rates.get(rateKey, {type: 'json'}).catch(() => null);
  const count = Number(prior?.count || 0);
  if (count >= RATE_MAX) return Response.json({error: 'Too many events.'}, {status: 429, headers: {'Retry-After': '600'}});
  await rates.setJSON(rateKey, {count: count + 1});

  const record = {
    created_at_utc: new Date().toISOString(),
    event,
    path: clean(payload.path, 120),
    label: clean(payload.label, 60),
    referrer: clean(payload.referrer, 240),
    utm_source: clean(payload.utm_source, 80),
    utm_medium: clean(payload.utm_medium, 80),
    utm_campaign: clean(payload.utm_campaign, 80),
    visit_id: clean(payload.visit_id, 64),
  };
  await getStore('analytics-events').setJSON(`${Date.now()}-${randomUUID()}`, record);
  return new Response(null, {status: 204});
};
