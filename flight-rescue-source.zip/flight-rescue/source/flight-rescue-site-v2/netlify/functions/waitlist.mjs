import { createHash } from 'node:crypto';
import { getStore } from '@netlify/blobs';

const CONSENT_VERSION = 'launch-beta-sms-v3';
const NAME_RE = /^[A-Za-zÀ-ÖØ-öø-ÿ' .-]{1,50}$/u;
const EMAIL_RE = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
const WINDOW_MS = 10 * 60 * 1000;
const RATE_MAX = 5;

const json = (status, payload, extra = {}) => new Response(JSON.stringify(payload), {
  status,
  headers: {'Content-Type': 'application/json; charset=utf-8', ...extra}
});

const digest = value => createHash('sha256').update(value).digest('hex');

const normalizePhone = value => {
  let digits = String(value || '').replace(/\D/g, '');
  if (digits.length === 11 && digits.startsWith('1')) digits = digits.slice(1);
  if (digits.length !== 10 || '01'.includes(digits[0]) || '01'.includes(digits[3])) return null;
  return `+1${digits}`;
};

const cleanName = value => {
  const cleaned = String(value || '').trim().replace(/\s+/g, ' ');
  return NAME_RE.test(cleaned) ? cleaned : null;
};

const cleanEmail = value => {
  const cleaned = String(value || '').trim().toLowerCase();
  if (!cleaned) return '';
  return cleaned.length <= 254 && EMAIL_RE.test(cleaned) ? cleaned : null;
};

const getIp = request => (
  request.headers.get('x-nf-client-connection-ip') ||
  request.headers.get('cf-connecting-ip') ||
  request.headers.get('x-forwarded-for')?.split(',')[0]?.trim() ||
  'unknown'
);

export default async (request) => {
  if (request.method !== 'POST') return json(405, {error: 'Method not allowed.'}, {Allow: 'POST'});
  const type = request.headers.get('content-type') || '';
  if (!type.includes('application/json')) return json(400, {error: 'Invalid request.'});

  let payload;
  try {
    const raw = await request.text();
    if (!raw || raw.length > 8192) throw new Error('invalid');
    payload = JSON.parse(raw);
  } catch {
    return json(400, {error: 'Invalid request.'});
  }

  if (payload.website) return json(201, {ok: true});

  const rateStore = getStore('waitlist-rate-limits');
  const window = Math.floor(Date.now() / WINDOW_MS);
  const rateKey = `${window}/${digest(getIp(request))}`;
  const prior = await rateStore.get(rateKey, {type: 'json'}).catch(() => null);
  const count = Number(prior?.count || 0);
  if (count >= RATE_MAX) {
    return json(429, {error: 'Too many attempts. Please try again in a few minutes.'}, {'Retry-After': '600'});
  }
  await rateStore.setJSON(rateKey, {count: count + 1, expires_after_utc: new Date((window + 1) * WINDOW_MS).toISOString()});

  const firstName = cleanName(payload.first_name);
  const rawLastName = String(payload.last_name || '').trim().replace(/\s+/g, ' ');
  const lastName = rawLastName ? cleanName(rawLastName) : '';
  const phone = normalizePhone(payload.phone);
  const email = cleanEmail(payload.email);
  if (!firstName) return json(422, {error: 'Enter your first name.'});
  if (lastName === null) return json(422, {error: 'Enter a valid last name or leave it blank.'});
  if (!phone) return json(422, {error: 'Enter a valid U.S. mobile number.'});
  if (email === null) return json(422, {error: 'Enter a valid email address or leave it blank.'});
  if (payload.consent !== true) return json(422, {error: 'Consent is required to send the launch text.'});

  const source = String(payload.source || 'site').replace(/[^A-Za-z0-9_.-]/g, '').slice(0, 40) || 'site';
  const signupStore = getStore('waitlist-signups');
  const phoneKey = `phone/${digest(phone)}`;
  if (await signupStore.get(phoneKey, {type: 'json'}).catch(() => null)) {
    return json(200, {ok: true, duplicate: true});
  }

  const origin = new URL(request.url).origin;
  const form = new URLSearchParams({
    'form-name': 'flight-rescue-waitlist',
    first_name: firstName,
    last_name: lastName,
    phone,
    email,
    consent: 'yes',
    consent_version: CONSENT_VERSION,
    source,
  });
  const submitted = await fetch(`${origin}/waitlist.html`, {
    method: 'POST',
    headers: {'Content-Type': 'application/x-www-form-urlencoded'},
    body: form.toString(),
  });
  if (!submitted.ok) return json(502, {error: 'We could not add you right now. Please try again.'});

  await signupStore.setJSON(phoneKey, {
    created_at_utc: new Date().toISOString(),
    consent_version: CONSENT_VERSION,
    source,
  });
  return json(201, {ok: true, duplicate: false});
};
