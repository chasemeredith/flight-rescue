#!/usr/bin/env python3
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
errors = []
required = {
    "netlify.toml": ["publish = \"dist\"", 'from = "/api/waitlist"', 'from = "/api/events"', "Content-Security-Policy"],
    "netlify/functions/waitlist.mjs": ["getStore('waitlist-signups')", "CONSENT_VERSION = 'launch-beta-sms-v3'", "normalizePhone", "duplicate: true", "form-name"],
    "netlify/functions/events.mjs": ["getStore('analytics-events')", "waitlist_signup_success", "status: 204"],
    "scripts/build-netlify.py": ["FILES =", "security.txt", "copytree"],
    "waitlist.html": ['name="flight-rescue-waitlist"', 'data-netlify="true"', 'data-netlify-honeypot="website"'],
}
for relative, markers in required.items():
    path = ROOT / relative
    if not path.is_file():
        errors.append(f"Missing {relative}")
        continue
    text = path.read_text()
    for marker in markers:
        if marker not in text:
            errors.append(f"{relative} missing {marker}")
if errors:
    print("Netlify check failed:")
    print("\n".join(f"- {e}" for e in errors))
    sys.exit(1)
print("Netlify check passed: allowlisted build, secure headers, durable waitlist, dedupe, rate limits, and analytics functions present.")
