#!/usr/bin/env python3
"""Build the exact public allowlist for Netlify deployment."""
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / "dist"
FILES = [
    "index.html", "waitlist.html", "privacy.html", "terms.html",
    "sms-terms.html", "disclaimer.html", "styles.css", "waitlist.css",
    "legal.css", "script.js", "waitlist.js", "robots.txt",
    ".well-known/security.txt",
]

if DIST.exists():
    shutil.rmtree(DIST)
DIST.mkdir()
for relative in FILES:
    source = ROOT / relative
    if not source.is_file():
        raise SystemExit(f"Missing public file: {relative}")
    target = DIST / relative
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(source, target)
shutil.copytree(ROOT / "assets", DIST / "assets")
print(f"Built {DIST} with {len(FILES)} public files plus assets")
