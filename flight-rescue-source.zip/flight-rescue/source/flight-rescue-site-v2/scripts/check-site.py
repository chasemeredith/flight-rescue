#!/usr/bin/env python3
"""Small pre-release check for Flight Rescue's responsive themes and copy."""
from pathlib import Path
import re
import struct
import sys

ROOT = Path(__file__).resolve().parents[1]
html = (ROOT / "index.html").read_text()
css = (ROOT / "styles.css").read_text()
js = (ROOT / "script.js").read_text()
errors: list[str] = []


def luminance(hex_color: str) -> float:
    values = [int(hex_color[i:i + 2], 16) / 255 for i in (1, 3, 5)]
    linear = [v / 12.92 if v <= 0.04045 else ((v + 0.055) / 1.055) ** 2.4 for v in values]
    return 0.2126 * linear[0] + 0.7152 * linear[1] + 0.0722 * linear[2]


def contrast(foreground: str, background: str) -> float:
    light, dark = sorted((luminance(foreground), luminance(background)), reverse=True)
    return (light + 0.05) / (dark + 0.05)


required_css = [
    "@media (prefers-reduced-motion:reduce)",
    "@media(max-width:780px)",
    ".phone{height:740px;display:flex;flex-direction:column;overflow:hidden}",
    "overflow-y:auto;overflow-x:hidden;overscroll-behavior:contain",
    ".scroll-cue{position:absolute",
    ".scroll-cue.is-hidden{opacity:0;visibility:hidden}",
    "height:min(560px,68svh)",
    "overscroll-behavior-y:auto;-webkit-overflow-scrolling:touch",
    ".hero-actions{display:flex",
    ".proof-strip .proof-shell{min-height:0;display:grid",
    ".trip-factors{margin-top:12px;padding:24px",
    ".monitoring{background:#fff;color:#0d1e2f}",
    "#compare:before{content:''",
    ".compare-labels,.compare-grid .product{grid-template-rows:85px repeat(9,58px)}",
    ".product>span:nth-of-type(9)::before{content:'Live flight assistant'}",
    "#compare .comparison-disclaimer{display:block",
]
for marker in required_css:
    if marker not in css:
        errors.append(f"Missing CSS release marker: {marker}")

if css.count("{") != css.count("}"):
    errors.append("CSS braces are unbalanced")

for legacy in ("KEEP, WATCH, or ACT", ">KEEP<", ">WATCH<", ">ACT<", "AI powered"):
    if legacy in html:
        errors.append(f"Outdated copy remains: {legacy}")

for required_copy in ("Turbulence:</b>", "Weather:</b>", "Verified at", "Forecast unavailable"):
    if required_copy not in html:
        errors.append(f"Sample response is missing: {required_copy}")

if "<span>Live flight assistant</span>" not in html:
    errors.append("Comparison table is missing the Live flight assistant row")

for required_comparison_copy in (
    "Flighty Pro excels at live tracking",
    "<b>Flighty Pro</b>",
    "<b>TripIt Pro</b>",
    "<span>Alternate-flight search</span>",
    "Flighty and TripIt are trademarks of their respective owners.",
    "Flight Rescue is not affiliated with or endorsed by either company.",
):
    if required_comparison_copy not in html:
        errors.append(f"Comparison update is missing: {required_comparison_copy}")

compare_section = html.split('id="compare"', 1)[1].split('</section>', 1)[0]
product_blocks = re.findall(r'<div class="product(?: featured)?">(.*?)</div>', compare_section)
if len(product_blocks) != 3 or any(block.count('aria-label=') != 9 for block in product_blocks):
    errors.append("Every comparison product must have exactly nine capability values")

for required_copy in (
    "Join the Flight Rescue waitlist",
    "Join the private beta waitlist",
    "Live evidence before a recommendation.",
    "Flight Rescue does not book, cancel, or change reservations.",
    "PERSONALIZED TO YOUR TRIP",
):
    if required_copy not in html:
        errors.append(f"Conversion/trust update is missing: {required_copy}")

if "unless you explicitly approve" in html or "No booking changes without approval" in html:
    errors.append("Landing page still implies Flight Rescue can change a reservation")

for legal_href in ("privacy.html", "terms.html", "sms-terms.html", "disclaimer.html"):
    if f'href="{legal_href}"' not in html:
        errors.append(f"Landing page footer is missing legal link: {legal_href}")

footer_html = html.split('<footer class="shell site-footer">', 1)[1] if '<footer class="shell site-footer">' in html else ""
if "info@getflightrescue.com" in footer_html:
    errors.append("Footer should not repeat the questions email below the contact panel")
if "© 2026 Flight Rescue" not in footer_html:
    errors.append("Footer is missing the complete Flight Rescue copyright notice")
if "height:auto;min-height:0;padding-top:28px;padding-bottom:68px" not in css:
    errors.append("Landing-page footer must override the legacy fixed height so bottom spacing is visible")

for questions_marker in ('class="questions-contact shell"', "Talk to Flight Rescue.", "Questions about the waitlist"):
    if questions_marker not in html:
        errors.append(f"Landing page is missing prominent questions contact: {questions_marker}")

for faq_marker in (
    'class="faq-section shell"',
    "What does Flight Rescue do?",
    "Does Flight Rescue rebook my flight?",
    "Which travelers are supported in the private beta?",
    "How quickly will Flight Rescue respond?",
    "How does Flight Rescue handle my information?",
):
    if faq_marker not in html:
        errors.append(f"Landing page FAQ is missing: {faq_marker}")
if "What will it cost?" in html:
    errors.append("Pricing FAQ must remain omitted while pricing is undecided")

for launch_marker in (
    'class="hero-demo-choice"',
    'class="mid-waitlist-cta shell"',
    "Private beta launching first for U.S. travelers with U.S. mobile numbers.",
    'data-analytics-label="hero"',
    'data-analytics-label="mid-page"',
):
    if launch_marker not in html:
        errors.append(f"Landing-page conversion update is missing: {launch_marker}")

for metadata_marker in (
    '<link rel="canonical" href="https://getflightrescue.com/">',
    '<meta property="og:title"',
    '<meta property="og:image" content="https://getflightrescue.com/assets/flight-rescue-social.png">',
    '<meta name="twitter:card" content="summary_large_image">',
    '<link rel="icon" href="assets/flight-rescue-favicon.png" type="image/png">',
):
    if metadata_marker not in html:
        errors.append(f"Public sharing metadata is missing: {metadata_marker}")
social_image = ROOT / "assets" / "flight-rescue-social.png"
favicon = ROOT / "assets" / "flight-rescue-favicon.png"
if not social_image.exists():
    errors.append("Branded social-sharing image is missing")
else:
    with social_image.open("rb") as handle:
        header = handle.read(24)
    if len(header) < 24 or header[:8] != b"\x89PNG\r\n\x1a\n" or struct.unpack(">II", header[16:24]) != (1200, 630):
        errors.append("Social-sharing image must be a 1200x630 PNG")
if not favicon.exists():
    errors.append("Square Flight Rescue favicon is missing")

legal_canonicals = {
    "privacy.html": "https://getflightrescue.com/privacy.html",
    "terms.html": "https://getflightrescue.com/terms.html",
    "sms-terms.html": "https://getflightrescue.com/sms-terms.html",
    "disclaimer.html": "https://getflightrescue.com/disclaimer.html",
}
for legal_file, required_markers in {
    "privacy.html": ("Privacy Policy", "Information we collect", "support@getflightrescue.com"),
    "terms.html": ("Terms of Use", "Decision support only", "Third-party information"),
    "sms-terms.html": ("SMS Terms", "STOP", "HELP", "10 messages per month"),
    "disclaimer.html": ("Service Disclaimer", "not an airline", "not safety-critical"),
}.items():
    legal_text = (ROOT / legal_file).read_text() if (ROOT / legal_file).exists() else ""
    if not legal_text:
        errors.append(f"Missing legal page: {legal_file}")
        continue
    for marker in required_markers:
        if marker not in legal_text:
            errors.append(f"{legal_file} is missing required disclosure: {marker}")
    if f'<link rel="canonical" href="{legal_canonicals[legal_file]}">' not in legal_text:
        errors.append(f"{legal_file} is missing its production canonical URL")
    if 'assets/flight-rescue-favicon.png' not in legal_text:
        errors.append(f"{legal_file} is missing the Flight Rescue favicon")

if '<a class="launch-cta" href="waitlist.html?source=hero" data-analytics-label="hero"><b>Join the Flight Rescue waitlist</b>' not in html:
    errors.append("The hero CTA must link to the waitlist")

if '<a class="disabled waitlist-cta" href="waitlist.html?source=final" data-analytics-label="final">Join the private beta waitlist' not in html:
    errors.append("The final beta CTA must link to the waitlist")

if '<a class="beta" href="waitlist.html?source=nav" data-analytics-label="nav">Join waitlist</a>' not in html:
    errors.append("The navigation beta link must point to the waitlist")

waitlist_html = (ROOT / "waitlist.html").read_text()
waitlist_css = (ROOT / "waitlist.css").read_text()
waitlist_js = (ROOT / "waitlist.js").read_text()
server = (ROOT / "private_server.py").read_text()
if ".waitlist-card form[hidden],.waitlist-success[hidden]{display:none!important}" not in waitlist_css:
    errors.append("Waitlist hidden form/success states can render at the same time")
for marker in ('name="first_name"', 'name="last_name"', 'name="phone"', 'name="email" type="email"', 'name="consent"'):
    if marker not in waitlist_html:
        errors.append(f"Waitlist form field is missing: {marker}")
last_name_tag = re.search(r'<input[^>]+name="last_name"[^>]*>', waitlist_html)
if not last_name_tag or "required" in last_name_tag.group(0):
    errors.append("Last name must be visibly optional and must not be required")
if '<span class="field-label">Last name <small>(optional)</small></span>' not in waitlist_html:
    errors.append("Last name optional label is missing")
for marker in (
    "10 messages per month",
    "Email (optional)",
    "Consent is not a condition of purchase",
    "Reply STOP to opt out or HELP for help",
    'href="privacy.html"',
    'href="sms-terms.html"',
):
    if marker not in waitlist_html:
        errors.append(f"Waitlist SMS disclosure is missing: {marker}")
if "fetch('/api/waitlist'" not in waitlist_js:
    errors.append("Waitlist form does not submit to the collection endpoint")
for marker in (
    '"/api/waitlist"',
    "save_signup",
    'CONSENT_VERSION = "launch-beta-sms-v3"',
    "clean_email",
    '"email"',
    "SITE_PUBLIC",
    "RATE_LIMIT_MAX",
    "PUBLIC_FILES",
    "require_public_path",
    'path == "/api/events"',
    "save_event",
    "ANALYTICS_PATH",
):
    if marker not in server:
        errors.append(f"Waitlist collection endpoint is missing: {marker}")

for marker in ("waitlist_cta_click", "page_view", "data-analytics-label"):
    if marker not in js:
        errors.append(f"Landing-page conversion analytics is missing: {marker}")
for marker in ("waitlist_form_start", "waitlist_signup_success", "/api/events"):
    if marker not in waitlist_js:
        errors.append(f"Waitlist conversion analytics is missing: {marker}")
privacy_text = (ROOT / "privacy.html").read_text()
for marker in ("conversion analytics", "campaign parameters", "do not use analytics cookies"):
    if marker not in privacy_text:
        errors.append(f"Privacy analytics disclosure is missing: {marker}")

if 'class="decision-depth shell"' in html:
    errors.append("The repetitive six-step decision section should remain removed")

for foreground, background in (
    ("#0d1e2f", "#edf4f8"),
    ("#587083", "#edf4f8"),
    ("#27c3e6", "#0d1e2f"),
):
    ratio = contrast(foreground, background)
    if ratio < 4.5:
        errors.append(f"Theme contrast {foreground}/{background} is only {ratio:.2f}:1")

if re.search(r'<meta name="robots" content="noindex,nofollow,noarchive">', html + waitlist_html):
    errors.append("Public pages still contain noindex metadata")

if html.count('role="region" aria-label=') != 4 or html.count('tabindex="0"') != 4:
    errors.append("All four phone conversations must be labeled keyboard-scrollable regions")

if "thread.scrollTop = 0" not in js:
    errors.append("Scenario switching must reset the active conversation to the top")

for marker in ("Scroll conversation", "scrollCueSeen", "updateScrollCue"):
    if marker not in js:
        errors.append(f"Conversation scroll cue behavior is missing: {marker}")

if errors:
    print("Site check failed:")
    for error in errors:
        print(f"- {error}")
    sys.exit(1)

print("Site check passed: blue theme, strong outlines, fixed phone scrolling, responsive comparison, copy, privacy, reduced motion, and contrast.")
